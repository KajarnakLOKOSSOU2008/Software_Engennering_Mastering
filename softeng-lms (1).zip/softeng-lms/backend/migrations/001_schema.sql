-- SOFTENG LMS — Database Schema v1.0
-- Executer dans Supabase SQL Editor

CREATE TABLE IF NOT EXISTS users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email VARCHAR(255) UNIQUE NOT NULL,
  name VARCHAR(255),
  avatar_url VARCHAR(255),
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS modules (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  slug VARCHAR(100) UNIQUE NOT NULL,
  title VARCHAR(255) NOT NULL,
  description TEXT,
  order_index INT,
  duration_hours INT,
  difficulty VARCHAR(50) DEFAULT 'intermediate',
  icon VARCHAR(50),
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS lessons (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  module_id UUID NOT NULL REFERENCES modules(id) ON DELETE CASCADE,
  slug VARCHAR(100) NOT NULL,
  title VARCHAR(255) NOT NULL,
  content TEXT,
  duration_minutes INT,
  order_index INT,
  created_at TIMESTAMP DEFAULT NOW(),
  UNIQUE(module_id, slug)
);

CREATE TABLE IF NOT EXISTS exercises (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  lesson_id UUID NOT NULL REFERENCES lessons(id) ON DELETE CASCADE,
  title VARCHAR(255) NOT NULL,
  description TEXT,
  starter_code TEXT,
  solution_code TEXT,
  test_cases JSONB,
  difficulty VARCHAR(50) DEFAULT 'medium',
  language VARCHAR(50) DEFAULT 'python',
  order_index INT,
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS exercise_submissions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  exercise_id UUID NOT NULL REFERENCES exercises(id) ON DELETE CASCADE,
  code TEXT NOT NULL,
  passed_tests INT DEFAULT 0,
  total_tests INT DEFAULT 0,
  status VARCHAR(50) DEFAULT 'pending',
  submitted_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS user_progress (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  lesson_id UUID NOT NULL,
  completed BOOLEAN DEFAULT FALSE,
  time_spent_minutes INT DEFAULT 0,
  completed_at TIMESTAMP,
  created_at TIMESTAMP DEFAULT NOW(),
  UNIQUE(user_id, lesson_id)
);

CREATE TABLE IF NOT EXISTS badges (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  slug VARCHAR(100) UNIQUE NOT NULL,
  name VARCHAR(255) NOT NULL,
  description TEXT,
  criteria JSONB,
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS user_badges (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  badge_id UUID NOT NULL REFERENCES badges(id) ON DELETE CASCADE,
  earned_at TIMESTAMP DEFAULT NOW(),
  UNIQUE(user_id, badge_id)
);

CREATE TABLE IF NOT EXISTS certificates (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  module_id VARCHAR(100) NOT NULL,
  certificate_code VARCHAR(255) UNIQUE DEFAULT gen_random_uuid()::text,
  issued_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS user_analytics (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL UNIQUE REFERENCES users(id) ON DELETE CASCADE,
  total_lessons_completed INT DEFAULT 0,
  total_exercises_solved INT DEFAULT 0,
  total_study_minutes INT DEFAULT 0,
  current_streak INT DEFAULT 0,
  best_streak INT DEFAULT 0,
  last_activity_at TIMESTAMP,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS notifications (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  type VARCHAR(50) NOT NULL,
  title VARCHAR(255) NOT NULL,
  body TEXT,
  read BOOLEAN DEFAULT false,
  data JSONB,
  created_at TIMESTAMP DEFAULT NOW()
);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_progress_user ON user_progress(user_id);
CREATE INDEX IF NOT EXISTS idx_progress_lesson ON user_progress(lesson_id);
CREATE INDEX IF NOT EXISTS idx_submissions_user ON exercise_submissions(user_id);
CREATE INDEX IF NOT EXISTS idx_notif_user ON notifications(user_id, read);

-- Row Level Security
ALTER TABLE user_progress ENABLE ROW LEVEL SECURITY;
ALTER TABLE exercise_submissions ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_analytics ENABLE ROW LEVEL SECURITY;
ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE certificates ENABLE ROW LEVEL SECURITY;

CREATE POLICY "own_progress" ON user_progress FOR ALL USING (user_id = auth.uid());
CREATE POLICY "own_submissions" ON exercise_submissions FOR ALL USING (user_id = auth.uid());
CREATE POLICY "own_analytics" ON user_analytics FOR ALL USING (user_id = auth.uid());
CREATE POLICY "own_notifications" ON notifications FOR ALL USING (user_id = auth.uid());
CREATE POLICY "own_certificates" ON certificates FOR ALL USING (user_id = auth.uid());

-- Auto-create analytics on user creation
CREATE OR REPLACE FUNCTION create_user_analytics()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO user_analytics (user_id) VALUES (NEW.id) ON CONFLICT DO NOTHING;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_user_analytics
AFTER INSERT ON users FOR EACH ROW EXECUTE FUNCTION create_user_analytics();

-- Increment stat helper
CREATE OR REPLACE FUNCTION increment_user_stat(user_id UUID, stat_type VARCHAR, increment INT DEFAULT 1)
RETURNS void AS $$
BEGIN
  CASE stat_type
    WHEN 'lessons' THEN UPDATE user_analytics SET total_lessons_completed = total_lessons_completed + increment, updated_at = NOW() WHERE user_id = $1;
    WHEN 'exercises' THEN UPDATE user_analytics SET total_exercises_solved = total_exercises_solved + increment, updated_at = NOW() WHERE user_id = $1;
    WHEN 'study_time' THEN UPDATE user_analytics SET total_study_minutes = total_study_minutes + increment, updated_at = NOW() WHERE user_id = $1;
  END CASE;
END;
$$ LANGUAGE plpgsql;

-- Badges seed
INSERT INTO badges (slug, name, description, criteria) VALUES
  ('first-step','Premier Pas','Complété ta première leçon','{"type":"lessons_completed","threshold":1}'),
  ('ten-exercises','10 Exercices','Résolu 10 exercices','{"type":"exercises_solved","threshold":10}'),
  ('twenty-exercises','20 Exercices','Résolu 20 exercices','{"type":"exercises_solved","threshold":20}'),
  ('fifty-exercises','50 Exercices','Expert! 50 exercices résolus','{"type":"exercises_solved","threshold":50}'),
  ('streak-7','Série 7 Jours','Appris 7 jours de suite','{"type":"streak","threshold":7}'),
  ('streak-30','Série 30 Jours','30 jours consécutifs!','{"type":"streak","threshold":30}'),
  ('module-1','Fondations','Module Fondations complété','{"type":"module","id":"01-fondations"}'),
  ('module-2','Architecte','Module Software Engineering complété','{"type":"module","id":"02-software-engineering"}'),
  ('module-3','Full-Stack Dev','Module Full-Stack complété','{"type":"module","id":"03-fullstack"}'),
  ('graduate','🎓 Diplômé','5 certificats obtenus','{"type":"certificates","threshold":5}')
ON CONFLICT (slug) DO NOTHING;