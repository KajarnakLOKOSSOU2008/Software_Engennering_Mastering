import { createContext, useContext, useEffect, useState } from "react";
const OfflineContext = createContext();
export function useOffline() { return useContext(OfflineContext); }
export function OfflineProvider({ children }) {
  const [isOnline, setIsOnline] = useState(true);
  const [pendingCount, setPendingCount] = useState(0);
  useEffect(() => {
    setIsOnline(navigator.onLine);
    const goOnline = () => setIsOnline(true);
    const goOffline = () => setIsOnline(false);
    window.addEventListener("online", goOnline);
    window.addEventListener("offline", goOffline);
    return () => { window.removeEventListener("online", goOnline); window.removeEventListener("offline", goOffline); };
  }, []);
  return (
    <OfflineContext.Provider value={{ isOnline, pendingCount }}>
      {children}
      {!isOnline && <div className="offline-banner">⚡ Mode hors-ligne</div>}
    </OfflineContext.Provider>
  );
}