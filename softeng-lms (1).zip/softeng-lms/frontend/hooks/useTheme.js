import { createContext, useContext, useEffect, useState } from "react";
const ThemeContext = createContext();
export function useTheme() { return useContext(ThemeContext); }
export function ThemeProvider({ children }) {
  const [theme, setTheme] = useState("light");
  useEffect(() => {
    const saved = localStorage.getItem("theme");
    const preferred = window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
    const initial = saved || preferred;
    setTheme(initial);
    document.documentElement.setAttribute("data-theme", initial);
  }, []);
  const toggle = () => {
    const next = theme === "light" ? "dark" : "light";
    setTheme(next);
    localStorage.setItem("theme", next);
    document.documentElement.setAttribute("data-theme", next);
  };
  return <ThemeContext.Provider value={{ theme, toggle, isDark: theme === "dark" }}>{children}</ThemeContext.Provider>;
}