import { useState, useEffect, useCallback } from "react";
import { createClient } from "@supabase/supabase-js";
const supabase = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL, process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY);
export function useProgress(userId) {
  const [progress, setProgress] = useState({});
  const [analytics, setAnalytics] = useState(null);
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    if (!userId) { setLoading(false); return; }
    Promise.all([
      supabase.from("user_progress").select("*").eq("user_id", userId),
      supabase.from("user_analytics").select("*").eq("user_id", userId).single(),
    ]).then(([{ data: prog }, { data: anal }]) => {
      if (prog) { const map = {}; prog.forEach(p => { map[p.lesson_id] = p; }); setProgress(map); }
      if (anal) setAnalytics(anal);
      setLoading(false);
    });
  }, [userId]);
  const markComplete = useCallback(async (lessonId) => {
    if (!userId) return;
    await supabase.from("user_progress").upsert({ user_id: userId, lesson_id: lessonId, completed: true, completed_at: new Date().toISOString() });
    setProgress(p => ({ ...p, [lessonId]: { completed: true } }));
  }, [userId]);
  const isCompleted = useCallback((lessonId) => progress[lessonId]?.completed === true, [progress]);
  const getModuleProgress = useCallback((lessonIds) => {
    if (!lessonIds?.length) return 0;
    const done = lessonIds.filter(id => progress[id]?.completed).length;
    return Math.round((done / lessonIds.length) * 100);
  }, [progress]);
  return { progress, analytics, loading, markComplete, isCompleted, getModuleProgress };
}