import { useEffect, useState, useCallback, createContext, useContext } from "react";
import { createClient } from "@supabase/supabase-js";
const supabase = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL, process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY);
const AuthContext = createContext();
export function useAuth() { return useContext(AuthContext); }
export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => { setUser(session?.user || null); setLoading(false); });
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_, session) => setUser(session?.user || null));
    return () => subscription?.unsubscribe();
  }, []);
  const signInWithMagicLink = useCallback(async (email) => {
    setLoading(true);
    const { error } = await supabase.auth.signInWithOtp({ email, options: { emailRedirectTo: `${window.location.origin}/auth/callback` } });
    setLoading(false);
    return error ? { success: false, error: error.message } : { success: true };
  }, []);
  const signInWithOAuth = useCallback(async (provider) => {
    await supabase.auth.signInWithOAuth({ provider, options: { redirectTo: `${window.location.origin}/auth/callback` } });
  }, []);
  const signOut = useCallback(async () => { await supabase.auth.signOut(); setUser(null); }, []);
  const updateProfile = useCallback(async (updates) => {
    const { data, error } = await supabase.from("user_profiles").upsert({ user_id: user.id, ...updates }).select().single();
    return error ? { success: false, error: error.message } : { success: true, data };
  }, [user?.id]);
  return <AuthContext.Provider value={{ user, loading, error, signInWithMagicLink, signInWithOAuth, signOut, updateProfile }}>{children}</AuthContext.Provider>;
}