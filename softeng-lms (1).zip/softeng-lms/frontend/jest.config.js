const nextJest = require('next/jest');
const config = nextJest({ dir: './' });
module.exports = config({
  testEnvironment: 'jest-environment-jsdom',
  moduleNameMapper: { '^@/(.*)$': '<rootDir>/$1' },
  setupFilesAfterFramework: [],
  testPathIgnorePatterns: ['<rootDir>/.next/', '<rootDir>/node_modules/'],
  collectCoverageFrom: ['lib/**/*.{js,jsx}', 'hooks/**/*.{js,jsx}', '!**/*.d.ts'],
});