import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/router";
import { useAuth } from "@/hooks/useAuth";
import { useTheme } from "@/hooks/useTheme";
const LINKS=[{href:"/",label:"Dashboard"},{href:"/courses",label:"Modules"},{href:"/projects",label:"Projets"},{href:"/leaderboard",label:"Classement"},{href:"/playground",label:"Playground"}];
export function Navbar() {
  const {user,signOut}=useAuth();
  const {isDark,toggle}=useTheme();
  const router=useRouter();
  const [open,setOpen]=useState(false);
  return (
    <nav style={{background:"var(--bg-surface)",borderBottom:"1px solid var(--border)",position:"sticky",top:0,zIndex:100}}>
      <div style={{maxWidth:1280,margin:"0 auto",padding:"0 1.5rem",height:64,display:"flex",alignItems:"center",gap:"1.5rem"}}>
        <Link href="/" style={{display:"flex",alignItems:"center",gap:".5rem",textDecoration:"none"}}>
          <span style={{fontSize:"1.4rem"}}>🎓</span>
          <span style={{fontWeight:800,fontSize:"1.05rem",color:"var(--color-primary)"}}>SoftEng LMS</span>
        </Link>
        <div style={{display:"flex",gap:".2rem",flex:1}}>
          {user&&LINKS.map(l=>(
            <Link key={l.href} href={l.href} style={{padding:".4rem .8rem",borderRadius:8,fontSize:".85rem",fontWeight:600,color:router.pathname===l.href?"var(--color-primary)":"var(--text-secondary)",background:router.pathname===l.href?"rgba(37,99,235,.1)":"transparent",textDecoration:"none"}}>
              {l.label}
            </Link>
          ))}
        </div>
        <div style={{marginLeft:"auto",display:"flex",alignItems:"center",gap:".75rem"}}>
          <button onClick={toggle} style={{width:36,height:36,borderRadius:9,border:"1px solid var(--border)",background:"var(--bg-elevated)",cursor:"pointer",fontSize:"1rem"}}>{isDark?"☀️":"🌙"}</button>
          {user?(
            <div style={{position:"relative"}}>
              <button onClick={()=>setOpen(o=>!o)} style={{display:"flex",alignItems:"center",gap:".5rem",padding:".35rem .75rem",border:"1px solid var(--border)",borderRadius:9,background:"var(--bg-elevated)",cursor:"pointer",color:"var(--text-primary)",fontSize:".88rem",fontWeight:600}}>
                <span style={{width:26,height:26,borderRadius:"50%",background:"linear-gradient(135deg,var(--color-primary),var(--color-secondary))",display:"flex",alignItems:"center",justifyContent:"center",color:"#fff",fontSize:".75rem",fontWeight:700}}>{user.email?.[0]?.toUpperCase()}</span>
                <span>{user.email?.split("@")[0]}</span>
              </button>
              {open&&(
                <div style={{position:"absolute",right:0,top:"calc(100% + 8px)",background:"var(--bg-surface)",border:"1px solid var(--border)",borderRadius:12,boxShadow:"var(--shadow-lg)",minWidth:180,padding:".5rem",zIndex:200}} className="animate-slideDown">
                  {[{href:"/profile",label:"👤 Profil"},{href:"/certificates",label:"🏆 Certificats"},{href:"/badges",label:"🏅 Badges"},{href:"/settings",label:"⚙️ Paramètres"}].map(i=>(
                    <Link key={i.href} href={i.href} onClick={()=>setOpen(false)} style={{display:"block",padding:".5rem .75rem",borderRadius:8,color:"var(--text-primary)",textDecoration:"none",fontSize:".88rem",fontWeight:500}}>{i.label}</Link>
                  ))}
                  <hr style={{border:"none",borderTop:"1px solid var(--border)",margin:".4rem 0"}}/>
                  <button onClick={()=>{signOut();setOpen(false)}} style={{width:"100%",textAlign:"left",padding:".5rem .75rem",borderRadius:8,border:"none",background:"none",color:"#ef4444",fontSize:".88rem",fontWeight:600,cursor:"pointer"}}>🚪 Déconnexion</button>
                </div>
              )}
            </div>
          ):(
            <div style={{display:"flex",gap:".5rem"}}>
              <Link href="/auth/login" style={{padding:".4rem .9rem",borderRadius:8,border:"1px solid var(--border)",color:"var(--text-primary)",textDecoration:"none",fontSize:".88rem",fontWeight:600}}>Connexion</Link>
              <Link href="/auth/signup" style={{padding:".4rem .9rem",borderRadius:8,background:"var(--color-primary)",color:"#fff",textDecoration:"none",fontSize:".88rem",fontWeight:700}}>S'inscrire</Link>
            </div>
          )}
        </div>
      </div>
    </nav>
  );
}