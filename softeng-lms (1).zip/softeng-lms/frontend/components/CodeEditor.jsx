import { useState, useCallback } from 'react';
import dynamic from 'next/dynamic';
import { executeCode, runTests } from '@/lib/codeExecution';
import toast from 'react-hot-toast';

const Editor = dynamic(() => import('@monaco-editor/react'), { ssr: false });

export function CodeEditor({ initialCode = '', language = 'python', testCases = [], exerciseId = null, onSubmit = null, readOnly = false }) {
  const [code, setCode] = useState(initialCode);
  const [output, setOutput] = useState('');
  const [running, setRunning] = useState(false);
  const [passedTests, setPassedTests] = useState(null);

  const handleRun = useCallback(async () => {
    if (running) return;
    setRunning(true);
    setOutput('⏳ Exécution…');
    try {
      const r = await executeCode({ code, language });
      setOutput(r.error ? `❌ ${r.error}` : r.output || '(Aucun output)');
    } catch (e) { setOutput(`❌ ${e.message}`); }
    finally { setRunning(false); }
  }, [code, language, running]);

  const handleSubmit = useCallback(async () => {
    if (running) return;
    setRunning(true);
    setOutput('⏳ Test en cours…');
    try {
      if (testCases.length > 0) {
        const result = await runTests(code, language, testCases);
        setPassedTests({ passed: result.passed, total: result.total });
        setOutput(`${result.passed}/${result.total} tests réussis

${result.results.map(r => `${r.passed ? '✅' : '❌'} ${r.testCase}`).join('
')}`);
        if (result.success) { toast.success('✅ Tous les tests passent!'); onSubmit?.(result); }
        else toast.error(`${result.passed}/${result.total} tests réussis`);
      } else {
        const r = await executeCode({ code, language });
        setOutput(r.output || r.error || '(Aucun output)');
        toast.success('Code exécuté!');
        onSubmit?.({ code });
      }
    } catch (e) { setOutput(`❌ ${e.message}`); toast.error('Erreur'); }
    finally { setRunning(false); }
  }, [code, language, testCases, running, onSubmit]);

  return (
    <div style={{ border: '1px solid var(--border)', borderRadius: 12, overflow: 'hidden', background: '#0d1117' }}>
      {/* Header */}
      <div style={{ background: '#161b22', borderBottom: '1px solid #21262d', padding: '.55rem 1rem', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <span style={{ fontSize: '.75rem', color: '#7d8590', fontFamily: 'monospace' }}>
          {language === 'python' ? 'main.py' : language === 'javascript' ? 'main.js' : language === 'rust' ? 'main.rs' : `main.${language}`}
        </span>
        <div style={{ display: 'flex', gap: '.5rem' }}>
          <button onClick={handleRun} disabled={running} style={{ padding: '.35rem .85rem', borderRadius: 7, border: 'none', background: running ? '#334155' : '#1d6a36', color: '#fff', fontWeight: 700, cursor: 'pointer', fontSize: '.8rem' }}>
            {running ? '⟳' : '▶'} Exécuter
          </button>
          {exerciseId && (
            <button onClick={handleSubmit} disabled={running} style={{ padding: '.35rem .85rem', borderRadius: 7, border: 'none', background: running ? '#334155' : '#1d4ed8', color: '#fff', fontWeight: 700, cursor: 'pointer', fontSize: '.8rem' }}>
              ✓ Soumettre
            </button>
          )}
          <button onClick={() => { setCode(initialCode); setOutput(''); setPassedTests(null); }} style={{ padding: '.35rem .7rem', borderRadius: 7, border: '1px solid #30363d', background: 'transparent', color: '#7d8590', cursor: 'pointer', fontSize: '.8rem' }}>
            ↺
          </button>
        </div>
      </div>

      {/* Editor */}
      <Editor
        height="320px"
        language={language}
        value={code}
        onChange={v => setCode(v || '')}
        theme="vs-dark"
        options={{ fontSize: 14, fontFamily: 'JetBrains Mono, monospace', minimap: { enabled: false }, lineNumbers: 'on', scrollBeyondLastLine: false, wordWrap: 'on', tabSize: 2, automaticLayout: true, padding: { top: 10 }, readOnly }}
      />

      {/* Output */}
      {(output || passedTests !== null) && (
        <div style={{ background: '#0d1117', borderTop: '1px solid #21262d', padding: '.75rem 1rem' }}>
          {passedTests !== null && (
            <div style={{ fontSize: '.8rem', fontWeight: 700, marginBottom: '.4rem', color: passedTests.passed === passedTests.total ? '#34d399' : '#f87171' }}>
              {passedTests.passed === passedTests.total ? '✅' : '❌'} {passedTests.passed}/{passedTests.total} tests réussis
            </div>
          )}
          <pre style={{ margin: 0, fontFamily: 'JetBrains Mono, monospace', fontSize: 12.5, lineHeight: 1.65, color: output.startsWith('❌') ? '#f87171' : '#e6edf3', whiteSpace: 'pre-wrap', wordBreak: 'break-word', maxHeight: 200, overflowY: 'auto' }}>
            {output}
          </pre>
        </div>
      )}

      {/* Test cases */}
      {testCases.length > 0 && (
        <div style={{ background: '#161b22', borderTop: '1px solid #21262d', padding: '.6rem 1rem' }}>
          <div style={{ fontSize: '.7rem', color: '#484f58', fontWeight: 700, marginBottom: '.4rem', letterSpacing: '.05em' }}>TEST CASES</div>
          <div style={{ display: 'flex', gap: '1rem', flexWrap: 'wrap' }}>
            {testCases.map((tc, i) => (
              <div key={i} style={{ fontSize: '.75rem', fontFamily: 'monospace', color: '#7d8590' }}>
                <span style={{ color: '#388bfd' }}>In:</span> {tc.input || '(vide)'} → <span style={{ color: '#34d399' }}>Out:</span> {tc.expected}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}