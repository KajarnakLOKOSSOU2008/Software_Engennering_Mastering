import { Html, Head, Main, NextScript } from "next/document";
export default function Document() {
  return (
    <Html lang="fr">
      <Head>
        <link rel="preconnect" href="https://fonts.googleapis.com"/>
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous"/>
        <link href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;700&family=Sora:wght@300;400;600;700;800&display=swap" rel="stylesheet"/>
        <link rel="manifest" href="/manifest.json"/>
        <meta name="theme-color" content="#2563eb"/>
        <meta name="apple-mobile-web-app-capable" content="yes"/>
        <meta name="apple-mobile-web-app-title" content="SoftEng LMS"/>
        <link rel="apple-touch-icon" href="/icons/icon-192.png"/>
        <meta property="og:type" content="website"/>
        <meta property="og:title" content="SoftEng LMS — Formation Ingénieur Logiciel"/>
        <meta property="og:description" content="700+ heures. Algorithmes, Full-Stack, DevOps, IA. Gratuit et offline."/>
        <meta name="robots" content="index, follow"/>
      </Head>
      <body>
        <Main/>
        <NextScript/>
      </body>
    </Html>
  );
}