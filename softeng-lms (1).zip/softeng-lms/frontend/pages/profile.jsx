import { useState, useEffect } from "react";
import { useRouter } from "next/router";
import { Navbar } from "@/components/Navbar";
import { useAuth } from "@/hooks/useAuth";
import { useProgress } from "@/hooks/useProgress";
import { createClient } from "@supabase/supabase-js";
import toast from "react-hot-toast";

const sb = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL, process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY);

export default function Profile() {
  const { user, signOut, loading } = useAuth();
  const router = useRouter();
  const { analytics } = useProgress(user?.id);
  const [form, setForm] = useState({ name: "", bio: "", github_url: "", linkedin_url: "" });
  const [saving, setSaving] = useState(false);

  useEffect(() => { if (!loading && !user) router.push("/auth/login"); }, [user, loading]);
  useEffect(() => {
    if (user) sb.from("users").select("name,avatar_url").eq("id", user.id).single().then(({ data }) => { if (data) setForm(f => ({ ...f, name: data.name || "" })); });
  }, [user]);

  const save = async () => {
    setSaving(true);
    await sb.from("users").update({ name: form.name }).eq("id", user.id);
    await sb.from("user_profiles").upsert({ user_id: user.id, bio: form.bio, github_url: form.github_url, linkedin_url: form.linkedin_url }, { onConflict: "user_id" });
    toast.success("Profil mis à jour!");
    setSaving(false);
  };

  if (!user) return null;
  const xp = analytics ? ((analytics.total_lessons_completed||0)*100+(analytics.total_exercises_solved||0)*50) : 0;

  return (
    <div style={{ minHeight: "100vh", background: "var(--bg-main)" }}>
      <Navbar />
      <main style={{ maxWidth: 800, margin: "0 auto", padding: "2.5rem 1.5rem" }}>
        <div className="animate-slideUp" style={{ marginBottom: "2rem" }}>
          <h1 style={{ fontSize: "2rem", fontWeight: 800 }}>👤 Mon Profil</h1>
        </div>

        {/* Avatar + stats */}
        <div className="card" style={{ padding: "2rem", marginBottom: "1.5rem", display: "flex", gap: "2rem", alignItems: "center", flexWrap: "wrap" }}>
          <div style={{ width: 72, height: 72, borderRadius: "50%", background: "linear-gradient(135deg,var(--color-primary),var(--color-secondary))", display: "flex", alignItems: "center", justifyContent: "center", color: "#fff", fontWeight: 800, fontSize: "1.75rem", flexShrink: 0 }}>
            {user.email?.[0]?.toUpperCase()}
          </div>
          <div style={{ flex: 1 }}>
            <div style={{ fontWeight: 800, fontSize: "1.2rem" }}>{form.name || user.email?.split("@")[0]}</div>
            <div style={{ color: "var(--text-muted)", fontSize: ".88rem", marginBottom: ".75rem" }}>{user.email}</div>
            <div style={{ display: "flex", gap: "1.25rem", flexWrap: "wrap" }}>
              {[["📚", analytics?.total_lessons_completed||0, "Leçons"],["✅", analytics?.total_exercises_solved||0, "Exercices"],["⭐", xp, "XP"],["🔥", analytics?.current_streak||0, "Jours"]].map(([i,v,l])=>(
                <div key={l} style={{ textAlign: "center" }}>
                  <div style={{ fontSize: ".7rem", color: "var(--text-muted)" }}>{i} {l}</div>
                  <div style={{ fontWeight: 800, color: "var(--color-primary)" }}>{v}</div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Edit form */}
        <div className="card" style={{ padding: "2rem", marginBottom: "1.5rem" }}>
          <h2 style={{ fontSize: "1.1rem", fontWeight: 700, marginBottom: "1.5rem" }}>Modifier le profil</h2>
          {[["name","Nom affiché","Jean Dupont"],["bio","Bio","Développeur passionné…"],["github_url","GitHub URL","https://github.com/username"],["linkedin_url","LinkedIn URL","https://linkedin.com/in/username"]].map(([k,label,ph])=>(
            <div key={k} style={{ marginBottom: "1.1rem" }}>
              <label style={{ display: "block", fontWeight: 600, fontSize: ".85rem", marginBottom: ".4rem", color: "var(--text-secondary)" }}>{label}</label>
              {k === "bio" ? (
                <textarea value={form[k]} onChange={e=>setForm(f=>({...f,[k]:e.target.value}))} placeholder={ph} rows={3} style={{ width: "100%", padding: ".7rem 1rem", borderRadius: 9, border: "1px solid var(--border)", background: "var(--bg-elevated)", color: "var(--text-primary)", fontSize: ".9rem", resize: "vertical", fontFamily: "var(--font-body)" }}/>
              ) : (
                <input value={form[k]} onChange={e=>setForm(f=>({...f,[k]:e.target.value}))} placeholder={ph} style={{ width: "100%", padding: ".7rem 1rem", borderRadius: 9, border: "1px solid var(--border)", background: "var(--bg-elevated)", color: "var(--text-primary)", fontSize: ".9rem" }}/>
              )}
            </div>
          ))}
          <button onClick={save} disabled={saving} style={{ padding: ".7rem 2rem", borderRadius: 9, border: "none", background: saving ? "var(--border)" : "var(--color-primary)", color: "#fff", fontWeight: 700, cursor: "pointer" }}>
            {saving ? "Sauvegarde…" : "Sauvegarder"}
          </button>
        </div>

        {/* Danger */}
        <div style={{ padding: "1.5rem", background: "#fef2f2", border: "1px solid #fecaca", borderRadius: 12 }}>
          <h3 style={{ fontWeight: 700, color: "#991b1b", marginBottom: ".5rem" }}>Zone Sensible</h3>
          <button onClick={() => { if(confirm("Se déconnecter?")) signOut().then(()=>router.push("/")); }} style={{ padding: ".6rem 1.4rem", borderRadius: 8, border: "none", background: "#dc2626", color: "#fff", fontWeight: 700, cursor: "pointer", fontSize: ".88rem" }}>
            🚪 Se déconnecter
          </button>
        </div>
      </main>
    </div>
  );
}