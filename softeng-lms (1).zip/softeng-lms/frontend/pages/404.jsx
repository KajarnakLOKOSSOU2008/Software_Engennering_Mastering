import Link from "next/link";
export default function NotFound() {
  return (
    <div style={{minHeight:"100vh",background:"var(--bg-main)",display:"flex",alignItems:"center",justifyContent:"center",textAlign:"center",padding:"2rem"}}>
      <div>
        <div style={{fontSize:"6rem",fontWeight:900,color:"var(--color-primary)"}}>404</div>
        <h1 style={{fontSize:"2rem",fontWeight:800,marginBottom:"1rem"}}>Page introuvable</h1>
        <p style={{color:"var(--text-secondary)",marginBottom:"2rem"}}>La page que tu cherches n'existe pas.</p>
        <Link href="/" style={{padding:".8rem 2rem",background:"var(--color-primary)",color:"#fff",borderRadius:10,textDecoration:"none",fontWeight:700}}>← Accueil</Link>
      </div>
    </div>
  );
}