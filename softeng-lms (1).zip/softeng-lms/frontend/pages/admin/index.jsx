import { useState, useEffect } from "react";
import { Navbar } from "@/components/Navbar";
import { useAuth } from "@/hooks/useAuth";
import { useRouter } from "next/router";
import { createClient } from "@supabase/supabase-js";

const sb = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL, process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY);
const ADMINS = (process.env.NEXT_PUBLIC_ADMIN_EMAILS||"").split(",");

export default function Admin() {
  const { user, loading } = useAuth();
  const router = useRouter();
  const [tab, setTab] = useState("overview");
  const [stats, setStats] = useState(null);
  const [users, setUsers] = useState([]);

  useEffect(() => {
    if (!loading) {
      if (!user || !ADMINS.includes(user.email)) { router.replace("/"); return; }
      Promise.all([
        sb.from("users").select("*",{count:"exact",head:true}),
        sb.from("exercise_submissions").select("*",{count:"exact",head:true}),
        sb.from("certificates").select("*",{count:"exact",head:true}),
        sb.from("users").select("id,email,name,created_at").order("created_at",{ascending:false}).limit(50),
      ]).then(([{count:u},{count:s},{count:c},{data:usersData}])=>{
        setStats({users:u,submissions:s,certs:c});
        setUsers(usersData||[]);
      });
    }
  }, [user, loading]);

  if (!user) return null;

  return (
    <div style={{ minHeight: "100vh", background: "var(--bg-main)" }}>
      <Navbar/>
      <main style={{ maxWidth: 1100, margin: "0 auto", padding: "2rem 1.5rem" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "2rem" }}>
          <div>
            <h1 style={{ fontSize: "1.75rem", fontWeight: 800 }}>⚙️ Admin</h1>
            <p style={{ color: "var(--text-muted)", fontSize: ".85rem" }}>{user.email}</p>
          </div>
          <span className="badge badge-purple">Admin</span>
        </div>

        <div style={{ display: "flex", gap: ".5rem", marginBottom: "2rem" }}>
          {[["overview","📊 Overview"],["users","👥 Utilisateurs"],["content","📚 Contenu"]].map(([v,l])=>(
            <button key={v} onClick={()=>setTab(v)} style={{ padding:".55rem 1rem",borderRadius:9,border:"none",background:tab===v?"var(--color-primary)":"var(--bg-elevated)",color:tab===v?"#fff":"var(--text-secondary)",fontWeight:700,fontSize:".85rem",cursor:"pointer" }}>{l}</button>
          ))}
        </div>

        {tab==="overview"&&(
          <div>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: "1rem", marginBottom: "2rem" }}>
              {[["👥","Utilisateurs",stats?.users??"…"],["✅","Soumissions",stats?.submissions??"…"],["🏆","Certificats",stats?.certs??"…"]].map(([i,l,v])=>(
                <div key={l} className="card" style={{ padding: "1.5rem", textAlign: "center" }}>
                  <div style={{ fontSize: "2rem", marginBottom: ".4rem" }}>{i}</div>
                  <div style={{ fontSize: "1.75rem", fontWeight: 800, color: "var(--color-primary)" }}>{v}</div>
                  <div style={{ fontSize: ".8rem", color: "var(--text-muted)" }}>{l}</div>
                </div>
              ))}
            </div>
          </div>
        )}

        {tab==="users"&&(
          <div className="card" style={{ overflow: "hidden" }}>
            <div style={{ padding: "1rem 1.25rem", borderBottom: "1px solid var(--border)", fontWeight: 700 }}>Utilisateurs ({users.length})</div>
            <div style={{ overflowX: "auto" }}>
              <table style={{ width: "100%", borderCollapse: "collapse" }}>
                <thead>
                  <tr style={{ background: "var(--bg-elevated)" }}>
                    {["Email","Nom","Inscrit"].map(h=><th key={h} style={{ padding:".75rem 1rem",textAlign:"left",fontSize:".8rem",fontWeight:700,color:"var(--text-muted)" }}>{h}</th>)}
                  </tr>
                </thead>
                <tbody>
                  {users.map(u=>(
                    <tr key={u.id} style={{ borderTop: "1px solid var(--border)" }}>
                      <td style={{ padding:".7rem 1rem",fontSize:".85rem",fontFamily:"monospace" }}>{u.email}</td>
                      <td style={{ padding:".7rem 1rem",fontSize:".85rem" }}>{u.name||"—"}</td>
                      <td style={{ padding:".7rem 1rem",fontSize:".75rem",color:"var(--text-muted)" }}>{new Date(u.created_at).toLocaleDateString("fr-FR")}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {tab==="content"&&(
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(240px,1fr))", gap: "1rem" }}>
            {[["01","🔧","Fondations",8,15],["02","🏗️","Software Eng.",6,12],["03","🌐","Full-Stack",6,20],["04","⚙️","DevOps",6,10],["05","💼","Carrière",5,8],["06","⚡","Extra Stacks",4,6],["07","🔐","Sécurité",3,5],["08","🌍","Open Source",3,4],["09","🤖","IA & ML",3,4],["10","⛓️","Blockchain",2,3]].map(([id,icon,name,lessons,exercises])=>(
              <div key={id} className="card" style={{ padding: "1.25rem" }}>
                <div style={{ fontSize: "1.75rem", marginBottom: ".5rem" }}>{icon}</div>
                <div style={{ fontWeight: 700, marginBottom: ".3rem" }}>Module {id}: {name}</div>
                <div style={{ fontSize: ".75rem", color: "var(--text-muted)" }}>📖 {lessons} leçons · ✅ {exercises} exercices</div>
              </div>
            ))}
          </div>
        )}
      </main>
    </div>
  );
}