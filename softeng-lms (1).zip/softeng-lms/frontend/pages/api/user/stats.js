import { createClient } from "@supabase/supabase-js";
const sb = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL, process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY);
export default async function handler(req,res) {
  if(req.method!=="GET") return res.status(405).end();
  const userId=req.query.user_id||req.headers["x-user-id"];
  if(!userId) return res.status(400).json({error:"user_id required"});
  const {data}=await sb.from("user_analytics").select("*").eq("user_id",userId).single();
  const {data:badges}=await sb.from("user_badges").select("badge_id").eq("user_id",userId);
  const {data:certs}=await sb.from("certificates").select("module_id").eq("user_id",userId);
  return res.status(200).json({
    lessons_completed:data?.total_lessons_completed||0,
    exercises_solved:data?.total_exercises_solved||0,
    study_minutes:data?.total_study_minutes||0,
    current_streak:data?.current_streak||0,
    badges_count:badges?.length||0,
    certificates_count:certs?.length||0,
  });
}