const IDX=[
  {id:"01-01",type:"lesson",title:"Notation O(n) et Complexité",module:"01-fondations",href:"/courses/01-fondations/01-01",tags:"big o complexity algorithme"},
  {id:"01-02",type:"lesson",title:"Arrays et Listes Liées",module:"01-fondations",href:"/courses/01-fondations/01-02",tags:"array linked list structure"},
  {id:"02-01",type:"lesson",title:"Principes SOLID",module:"02-software-engineering",href:"/courses/02-software-engineering/02-01",tags:"solid srp ocp lsp architecture"},
  {id:"02-02",type:"lesson",title:"Design Patterns GoF",module:"02-software-engineering",href:"/courses/02-software-engineering/02-02",tags:"design pattern singleton factory observer"},
  {id:"03-01",type:"lesson",title:"React Hooks State Effects",module:"03-fullstack",href:"/courses/03-fullstack/03-01",tags:"react hooks usestate useeffect frontend"},
  {id:"03-02",type:"lesson",title:"Node.js Express APIs REST",module:"03-fullstack",href:"/courses/03-fullstack/03-02",tags:"node express api rest backend"},
  {id:"03-03",type:"lesson",title:"Databases SQL NoSQL",module:"03-fullstack",href:"/courses/03-fullstack/03-03",tags:"sql postgresql mongodb nosql database"},
  {id:"04-01",type:"lesson",title:"Docker Containerization",module:"04-devops",href:"/courses/04-devops/04-01",tags:"docker container image dockerfile"},
  {id:"04-02",type:"lesson",title:"Kubernetes Orchestration",module:"04-devops",href:"/courses/04-devops/04-02",tags:"kubernetes k8s pod deployment service"},
  {id:"05-02",type:"lesson",title:"Technical Interviews",module:"05-career",href:"/courses/05-career/05-02",tags:"interview leetcode coding algorithme"},
  {id:"06-01",type:"lesson",title:"Rust Sécurité Mémoire",module:"06-extra-stacks",href:"/courses/06-extra-stacks/06-01",tags:"rust ownership borrowing memory"},
  {id:"07-01",type:"lesson",title:"OWASP Top 10 Sécurité",module:"07-security-performance",href:"/courses/07-security-performance/07-01",tags:"security owasp xss csrf injection"},
  {id:"09-01",type:"lesson",title:"LLMs APIs OpenAI Anthropic",module:"09-ai-ml-engineering",href:"/courses/09-ai-ml-engineering/09-01",tags:"llm openai anthropic claude gpt ai"},
  {id:"10-01",type:"lesson",title:"Blockchain Solidity NFT",module:"10-blockchain-web3",href:"/courses/10-blockchain-web3/10-01",tags:"blockchain solidity ethereum nft web3"},
];
export default function handler(req,res){
  if(req.method!=="GET") return res.status(405).end();
  const {q=""}=req.query; if(!q.trim()) return res.status(200).json({results:[]});
  const lq=q.toLowerCase();
  const results=IDX.filter(i=>i.title.toLowerCase().includes(lq)||i.tags.includes(lq)).slice(0,15);
  res.setHeader("Cache-Control","public, max-age=60");
  return res.status(200).json({results,total:results.length});
}