import { createClient } from "@supabase/supabase-js";
const sb = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL, process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY);
export default async function handler(req,res){
  if(req.method!=="GET") return res.status(405).end();
  const {data}=await sb.from("user_analytics").select("user_id,total_lessons_completed,total_exercises_solved,total_study_minutes,current_streak,users(name,email)").order("total_exercises_solved",{ascending:false}).limit(100);
  const enriched=(data||[]).map((r,i)=>({rank:i+1,userId:r.user_id,name:r.users?.name||r.users?.email?.split("@")[0]||"Anonyme",xp:((r.total_lessons_completed||0)*100)+((r.total_exercises_solved||0)*50),exercises:r.total_exercises_solved||0,lessons:r.total_lessons_completed||0,streak:r.current_streak||0}));
  res.setHeader("Cache-Control","public, max-age=60");
  return res.status(200).json({leaderboard:enriched});
}