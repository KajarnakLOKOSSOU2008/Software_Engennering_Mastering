import { createClient } from "@supabase/supabase-js";
import { runTests } from "@/lib/codeExecution";
const sb = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL, process.env.SUPABASE_SERVICE_KEY||process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY);
export default async function handler(req,res) {
  if(req.method!=="POST") return res.status(405).end();
  const {user_id,exercise_id,code,language}=req.body;
  if(!user_id||!exercise_id||!code) return res.status(400).json({error:"Missing fields"});
  try {
    const {data:ex}=await sb.from("exercises").select("*").eq("id",exercise_id).single();
    const tests=ex?.test_cases||[];
    const results=tests.length>0?await runTests(code,language||"python",tests):{passed:0,total:0,success:true};
    const status=results.success?"passed":"failed";
    await sb.from("exercise_submissions").insert({user_id,exercise_id,code,passed_tests:results.passed,total_tests:results.total,status});
    if(results.success){
      await sb.from("user_progress").upsert({user_id,lesson_id:ex?.lesson_id||exercise_id,completed:true,completed_at:new Date().toISOString()});
      await sb.rpc("increment_user_stat",{user_id,stat_type:"exercises"}).catch(()=>{});
    }
    return res.status(200).json({success:results.success,status,testResults:results});
  } catch(e){ return res.status(500).json({error:e.message}); }
}