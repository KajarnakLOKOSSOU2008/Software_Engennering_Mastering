import { executeCode } from "@/lib/codeExecution";
export default async function handler(req,res) {
  if(req.method!=="POST") return res.status(405).end();
  const {code,language,stdin}=req.body;
  if(!code||!language) return res.status(400).json({error:"code et language requis"});
  try { const result=await executeCode({code,language,stdin}); return res.status(200).json({success:true,...result}); }
  catch(e) { return res.status(500).json({success:false,error:e.message}); }
}