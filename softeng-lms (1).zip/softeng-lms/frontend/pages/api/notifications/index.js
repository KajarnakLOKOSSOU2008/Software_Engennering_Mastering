import { createClient } from "@supabase/supabase-js";
const sb = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL, process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY);
export default async function handler(req,res){
  const userId=req.query.user_id||req.headers["x-user-id"];
  if(!userId) return res.status(401).json({error:"Unauthorized"});
  if(req.method==="GET"){ const {data}=await sb.from("notifications").select("*").eq("user_id",userId).order("created_at",{ascending:false}).limit(30); return res.status(200).json({notifications:data||[]}); }
  if(req.method==="PATCH"){ await sb.from("notifications").update({read:true}).eq("user_id",userId).eq("read",false); return res.status(200).json({success:true}); }
  res.status(405).end();
}