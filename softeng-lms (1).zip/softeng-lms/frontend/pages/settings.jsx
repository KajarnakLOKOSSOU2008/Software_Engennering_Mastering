import { useState } from "react";
import { Navbar } from "@/components/Navbar";
import { useAuth } from "@/hooks/useAuth";
import { useTheme } from "@/hooks/useTheme";
import { useRouter } from "next/router";
import toast from "react-hot-toast";

export default function Settings() {
  const { user, signOut } = useAuth();
  const { theme, toggle, isDark } = useTheme();
  const router = useRouter();
  const [notifs, setNotifs] = useState({ email_weekly: true, email_badges: true, push: false });
  const [privacy, setPrivacy] = useState({ leaderboard: true, public_profile: false });

  if (!user) return null;

  return (
    <div style={{ minHeight: "100vh", background: "var(--bg-main)" }}>
      <Navbar />
      <main style={{ maxWidth: 680, margin: "0 auto", padding: "2.5rem 1.5rem" }}>
        <h1 style={{ fontSize: "2rem", fontWeight: 800, marginBottom: "2rem" }}>⚙️ Paramètres</h1>

        {/* Appearance */}
        <div className="card" style={{ padding: "1.75rem", marginBottom: "1.5rem" }}>
          <h2 style={{ fontSize: "1.1rem", fontWeight: 700, marginBottom: "1.25rem" }}>🎨 Apparence</h2>
          <div style={{ display: "flex", gap: "1rem" }}>
            {[["light","☀️ Clair"],["dark","🌙 Sombre"]].map(([v,l])=>(
              <button key={v} onClick={() => { if(theme!==v) toggle(); }} style={{ flex: 1, padding: "1rem", borderRadius: 12, border: `2px solid ${theme===v?"var(--color-primary)":"var(--border)"}`, background: theme===v?"rgba(37,99,235,.08)":"var(--bg-elevated)", cursor: "pointer", fontWeight: 700, fontSize: ".9rem", color: "var(--text-primary)", transition: "all .2s" }}>
                {l}
              </button>
            ))}
          </div>
        </div>

        {/* Notifications */}
        <div className="card" style={{ padding: "1.75rem", marginBottom: "1.5rem" }}>
          <h2 style={{ fontSize: "1.1rem", fontWeight: 700, marginBottom: "1.25rem" }}>🔔 Notifications</h2>
          {[["email_weekly","Résumé hebdomadaire","Progression par email chaque semaine"],["email_badges","Nouveaux badges","Notifié quand tu gagnes un badge"],["push","Notifications push","Rappels en temps réel"]].map(([k,label,desc])=>(
            <label key={k} style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "1rem 0", borderBottom: "1px solid var(--border)", cursor: "pointer" }}>
              <div>
                <div style={{ fontWeight: 600, fontSize: ".9rem" }}>{label}</div>
                <div style={{ fontSize: ".78rem", color: "var(--text-muted)", marginTop: ".2rem" }}>{desc}</div>
              </div>
              <input type="checkbox" checked={notifs[k]} onChange={e=>setNotifs(n=>({...n,[k]:e.target.checked}))} style={{ width: 18, height: 18, cursor: "pointer" }}/>
            </label>
          ))}
        </div>

        {/* Danger */}
        <div style={{ padding: "1.5rem", background: "#fef2f2", border: "1px solid #fecaca", borderRadius: 12 }}>
          <h3 style={{ fontWeight: 700, color: "#991b1b", marginBottom: "1rem" }}>⚠️ Zone Sensible</h3>
          <button onClick={() => { if(confirm("Déconnexion?")) signOut().then(()=>router.push("/")); }} style={{ padding: ".6rem 1.4rem", borderRadius: 8, border: "none", background: "#dc2626", color: "#fff", fontWeight: 700, cursor: "pointer", fontSize: ".88rem" }}>
            🚪 Se déconnecter
          </button>
        </div>
      </main>
    </div>
  );
}