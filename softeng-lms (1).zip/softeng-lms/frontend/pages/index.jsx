import { useEffect, useState } from "react";
import Link from "next/link";
import { useAuth } from "@/hooks/useAuth";
import { useTheme } from "@/hooks/useTheme";
import { Navbar } from "@/components/Navbar";

const MODULES=[
  {id:"01-fondations",icon:"🔧",title:"Fondations",sub:"Algorithmes & Structures",hours:80,color:"#2563eb"},
  {id:"02-software-engineering",icon:"🏗️",title:"Software Eng.",sub:"SOLID & Design Patterns",hours:60,color:"#7c3aed"},
  {id:"03-fullstack",icon:"🌐",title:"Full-Stack",sub:"React · Node.js · DB",hours:120,color:"#059669"},
  {id:"04-devops",icon:"⚙️",title:"DevOps",sub:"Docker · K8s · CI/CD",hours:60,color:"#dc2626"},
  {id:"05-career",icon:"💼",title:"Carrière",sub:"Interviews & Soft Skills",hours:40,color:"#d97706"},
  {id:"06-extra-stacks",icon:"⚡",title:"Extra Stacks",sub:"Rust · Go · Python · Mobile",hours:100,color:"#0891b2"},
  {id:"07-security-performance",icon:"🔐",title:"Sécurité",sub:"OWASP · Perf · Microservices",hours:80,color:"#6d28d9"},
  {id:"08-open-source-entrepreneurship",icon:"🌍",title:"Open Source",sub:"Freelance · Startup",hours:50,color:"#0f766e"},
  {id:"09-ai-ml-engineering",icon:"🤖",title:"IA & ML",sub:"LLMs · RAG · Production",hours:80,color:"#b45309"},
  {id:"10-blockchain-web3",icon:"⛓️",title:"Blockchain",sub:"Solidity · DeFi · NFT",hours:60,color:"#6366f1"},
];

export default function Home() {
  const {user,loading}=useAuth();
  const [stats,setStats]=useState(null);
  const [mounted,setMounted]=useState(false);

  useEffect(()=>{setMounted(true);},[]);

  useEffect(()=>{
    if(user){
      fetch(`/api/user/stats?user_id=${user.id}`)
        .then(r=>r.json()).then(setStats).catch(()=>{});
    }
  },[user]);

  if(!mounted||loading) return (
    <div style={{minHeight:"100vh",background:"var(--bg-main)",display:"flex",alignItems:"center",justifyContent:"center"}}>
      <div style={{textAlign:"center"}}>
        <div style={{fontSize:"3rem",marginBottom:"1rem"}}>🎓</div>
        <div style={{color:"var(--text-muted)",fontWeight:600}}>Chargement…</div>
      </div>
    </div>
  );

  if(!user) return <Landing/>;

  const xp=stats?((stats.lessons_completed||0)*100+(stats.exercises_solved||0)*50+Math.floor((stats.study_minutes||0)/60)*10):0;
  const level=Math.floor(xp/1000)+1;
  const xpPct=((xp%1000)/1000)*100;

  return (
    <div style={{minHeight:"100vh",background:"var(--bg-main)"}}>
      <Navbar/>
      <main style={{maxWidth:1200,margin:"0 auto",padding:"2rem 1.5rem"}}>

        {/* Welcome bar */}
        <div className="card animate-slideUp" style={{padding:"1.5rem 2rem",marginBottom:"1.75rem",background:"linear-gradient(135deg,rgba(37,99,235,.07),rgba(124,58,237,.05))"}}>
          <div style={{display:"flex",alignItems:"center",gap:"1.25rem",flexWrap:"wrap"}}>
            <div style={{width:52,height:52,borderRadius:"50%",background:"linear-gradient(135deg,var(--color-primary),var(--color-secondary))",display:"flex",alignItems:"center",justifyContent:"center",color:"#fff",fontWeight:800,fontSize:"1.3rem",flexShrink:0}}>
              {user.email?.[0]?.toUpperCase()}
            </div>
            <div style={{flex:1}}>
              <h1 style={{fontSize:"1.2rem",fontWeight:800,marginBottom:".3rem"}}>Bonjour, {user.email?.split("@")[0]}! 👋</h1>
              <div style={{display:"flex",alignItems:"center",gap:".75rem",flexWrap:"wrap"}}>
                <span style={{background:"linear-gradient(135deg,#eab308,#d97706)",color:"#fff",padding:".2rem .7rem",borderRadius:999,fontSize:".75rem",fontWeight:800}}>Nv. {level}</span>
                <div style={{flex:1,minWidth:140}}>
                  <div style={{display:"flex",justifyContent:"space-between",fontSize:".7rem",color:"var(--text-muted)",marginBottom:".25rem"}}>
                    <span>{xp} XP</span><span>{level*1000} XP</span>
                  </div>
                  <div className="progress-bar" style={{height:7}}>
                    <div className="progress-fill" style={{width:`${xpPct}%`,background:"linear-gradient(90deg,#eab308,#f59e0b)"}}/>
                  </div>
                </div>
                {(stats?.current_streak||0)>0&&<span style={{background:"#fef3c7",color:"#92400e",padding:".2rem .7rem",borderRadius:999,fontSize:".75rem",fontWeight:800}}>🔥 {stats.current_streak}j</span>}
              </div>
            </div>
          </div>
        </div>

        {/* Stats */}
        <div style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:"1rem",marginBottom:"1.75rem"}} className="stagger">
          {[{icon:"📚",label:"Leçons",value:stats?.lessons_completed||0,color:"var(--color-primary)"},{icon:"✅",label:"Exercices",value:stats?.exercises_solved||0,color:"#16a34a"},{icon:"⏱️",label:"Heures",value:`${Math.floor((stats?.study_minutes||0)/60)}h`,color:"#d97706"},{icon:"⭐",label:"XP",value:xp,color:"#eab308"}].map(s=>(
            <div key={s.label} className="card animate-slideUp" style={{padding:"1.25rem",textAlign:"center"}}>
              <div style={{fontSize:"1.75rem",marginBottom:".35rem"}}>{s.icon}</div>
              <div style={{fontSize:"1.6rem",fontWeight:800,color:s.color,fontFamily:"var(--font-mono)"}}>{s.value}</div>
              <div style={{fontSize:".75rem",color:"var(--text-muted)",fontWeight:600}}>{s.label}</div>
            </div>
          ))}
        </div>

        {/* Modules */}
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:"1rem"}}>
          <h2 style={{fontSize:"1.1rem",fontWeight:800}}>📚 Modules</h2>
          <Link href="/courses" style={{fontSize:".85rem",color:"var(--color-primary)",textDecoration:"none",fontWeight:600}}>Voir tout →</Link>
        </div>
        <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(200px,1fr))",gap:"1rem",marginBottom:"2rem"}} className="stagger">
          {MODULES.map(m=>(
            <Link key={m.id} href={`/courses/${m.id}`} style={{textDecoration:"none"}}>
              <div className="card animate-slideUp" style={{padding:"1.1rem",cursor:"pointer"}}>
                <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:".75rem"}}>
                  <span style={{fontSize:"1.85rem"}}>{m.icon}</span>
                  <span style={{fontSize:".68rem",fontWeight:700,color:m.color,background:`${m.color}18`,padding:".15rem .5rem",borderRadius:999}}>{m.hours}h</span>
                </div>
                <div style={{fontWeight:800,fontSize:".88rem",marginBottom:".2rem"}}>{m.title}</div>
                <div style={{fontSize:".72rem",color:"var(--text-muted)",marginBottom:".75rem"}}>{m.sub}</div>
                <div className="progress-bar"><div className="progress-fill" style={{width:"0%",background:m.color}}/></div>
              </div>
            </Link>
          ))}
        </div>

        {/* Quick links */}
        <h2 style={{fontSize:"1.1rem",fontWeight:800,marginBottom:"1rem"}}>⚡ Accès Rapide</h2>
        <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(170px,1fr))",gap:".75rem"}}>
          {[{href:"/playground",icon:"⚡",label:"Playground",desc:"Coder librement"},{href:"/leaderboard",icon:"🏆",label:"Classement",desc:"Top apprenants"},{href:"/mentorship",icon:"🤝",label:"Mentorship",desc:"Sessions 1-on-1"},{href:"/projects",icon:"🚀",label:"Projets",desc:"Capstone projects"},{href:"/certificates",icon:"🎓",label:"Certificats",desc:"Mes diplômes"},{href:"/badges",icon:"🏅",label:"Badges",desc:"Mes récompenses"}].map(l=>(
            <Link key={l.href} href={l.href} style={{textDecoration:"none"}}>
              <div className="card" style={{padding:".9rem",cursor:"pointer",display:"flex",alignItems:"center",gap:".7rem"}}>
                <span style={{fontSize:"1.4rem",flexShrink:0}}>{l.icon}</span>
                <div><div style={{fontWeight:700,fontSize:".85rem"}}>{l.label}</div><div style={{fontSize:".7rem",color:"var(--text-muted)"}}>{l.desc}</div></div>
              </div>
            </Link>
          ))}
        </div>
      </main>
    </div>
  );
}

function Landing() {
  return (
    <div style={{minHeight:"100vh",background:"var(--bg-main)"}}>
      <nav style={{display:"flex",alignItems:"center",justifyContent:"space-between",padding:"1.25rem 2rem",borderBottom:"1px solid var(--border)",background:"var(--bg-surface)"}}>
        <span style={{fontSize:"1.3rem",fontWeight:800,color:"var(--color-primary)"}}>🎓 SoftEng LMS</span>
        <div style={{display:"flex",gap:".6rem"}}>
          <Link href="/auth/login" style={{padding:".45rem 1rem",borderRadius:8,border:"1px solid var(--border)",color:"var(--text-primary)",textDecoration:"none",fontWeight:600,fontSize:".88rem"}}>Connexion</Link>
          <Link href="/auth/signup" style={{padding:".45rem 1rem",borderRadius:8,background:"var(--color-primary)",color:"#fff",textDecoration:"none",fontWeight:700,fontSize:".88rem"}}>S'inscrire</Link>
        </div>
      </nav>
      <section style={{maxWidth:900,margin:"0 auto",padding:"5rem 2rem 3rem",textAlign:"center"}}>
        <div className="animate-slideUp">
          <div style={{display:"inline-flex",alignItems:"center",gap:".5rem",background:"rgba(37,99,235,.1)",border:"1px solid rgba(37,99,235,.2)",borderRadius:999,padding:".35rem 1rem",marginBottom:"1.75rem",fontSize:".82rem",color:"var(--color-primary)",fontWeight:700}}>
            ✨ 700+ heures · 10 modules · 50 langages · 100% gratuit
          </div>
          <h1 style={{fontSize:"clamp(2.2rem,6vw,4rem)",fontWeight:900,lineHeight:1.15,marginBottom:"1.5rem"}}>
            Deviens{" "}
            <span style={{background:"linear-gradient(135deg,var(--color-primary),var(--color-secondary))",WebkitBackgroundClip:"text",WebkitTextFillColor:"transparent"}}>Ingénieur Logiciel</span>
            {" "}de A à Z
          </h1>
          <p style={{fontSize:"1.1rem",color:"var(--text-secondary)",marginBottom:"2.5rem",maxWidth:560,margin:"0 auto 2.5rem"}}>
            Algorithmes, Full-Stack, DevOps, Rust, Go, IA, Blockchain. Éditeur intégré, certifications PDF, mode hors-ligne total.
          </p>
          <div style={{display:"flex",gap:"1rem",justifyContent:"center",flexWrap:"wrap"}}>
            <Link href="/auth/signup" style={{padding:".9rem 2.25rem",borderRadius:11,background:"linear-gradient(135deg,var(--color-primary),var(--color-secondary))",color:"#fff",textDecoration:"none",fontWeight:800,fontSize:"1rem",boxShadow:"0 8px 24px rgba(37,99,235,.3)"}}>Commencer Gratuitement →</Link>
            <Link href="/courses" style={{padding:".9rem 2.25rem",borderRadius:11,border:"1px solid var(--border)",background:"var(--bg-surface)",color:"var(--text-primary)",textDecoration:"none",fontWeight:700,fontSize:"1rem"}}>Voir les modules</Link>
          </div>
        </div>
      </section>
      <section style={{maxWidth:1100,margin:"0 auto",padding:"1rem 2rem 5rem"}}>
        <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(210px,1fr))",gap:"1.1rem"}} className="stagger">
          {[{icon:"⚡",t:"Offline-First",d:"100% fonctionnel sans internet"},{icon:"🖥️",t:"Éditeur Monaco",d:"50+ langages, tests auto"},{icon:"🏆",t:"Certificats PDF",d:"Professionnels, vérifiables"},{icon:"🤝",t:"Mentorship",d:"Sessions 1-on-1 avec seniors"},{icon:"📱",t:"Mobile & Web",d:"PWA + Capacitor iOS/Android"},{icon:"🆓",t:"Gratuit à vie",d:"MIT open-source, sans paywall"}].map(f=>(
            <div key={f.t} className="card animate-slideUp" style={{padding:"1.4rem"}}>
              <div style={{fontSize:"1.9rem",marginBottom:".65rem"}}>{f.icon}</div>
              <div style={{fontWeight:800,marginBottom:".35rem"}}>{f.t}</div>
              <div style={{fontSize:".82rem",color:"var(--text-secondary)",lineHeight:1.55}}>{f.d}</div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}