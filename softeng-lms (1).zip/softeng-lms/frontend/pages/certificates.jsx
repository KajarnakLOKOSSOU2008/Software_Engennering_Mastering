import { useState, useEffect } from "react";
import { Navbar } from "@/components/Navbar";
import { useAuth } from "@/hooks/useAuth";
import { generateCertificate } from "@/lib/certificateGenerator";
import { createClient } from "@supabase/supabase-js";
import toast from "react-hot-toast";

const sb=createClient(process.env.NEXT_PUBLIC_SUPABASE_URL,process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY);

const MODULES=[
  {id:"01-fondations",name:"Fondations : Algorithmes & Structures",icon:"🔧",hours:80},
  {id:"02-software-engineering",name:"Software Engineering : Design Patterns",icon:"🏗️",hours:60},
  {id:"03-fullstack",name:"Full-Stack : React, Node.js, Databases",icon:"🌐",hours:120},
  {id:"04-devops",name:"DevOps & Cloud : Docker, Kubernetes",icon:"⚙️",hours:60},
  {id:"05-career",name:"Carrière : Interviews & Soft Skills",icon:"💼",hours:40},
  {id:"06-extra-stacks",name:"Extra Stacks : Rust, Go, Python, Mobile",icon:"⚡",hours:100},
  {id:"07-security-performance",name:"Sécurité & Performance",icon:"🔐",hours:80},
  {id:"08-open-source-entrepreneurship",name:"Open Source & Entrepreneuriat",icon:"🌍",hours:50},
  {id:"09-ai-ml-engineering",name:"IA & ML pour Ingénieurs",icon:"🤖",hours:80},
  {id:"10-blockchain-web3",name:"Blockchain & Web3",icon:"⛓️",hours:60},
];

export default function Certificates() {
  const {user}=useAuth();
  const [certs,setCerts]=useState([]);
  const [loading,setLoading]=useState(true);
  const [generating,setGenerating]=useState(null);

  useEffect(()=>{
    if(user)sb.from("certificates").select("*").eq("user_id",user.id).then(({data})=>{if(data)setCerts(data);setLoading(false);});
    else setLoading(false);
  },[user]);

  const totalHours=certs.reduce((a,c)=>a+(MODULES.find(m=>m.id===c.module_id)?.hours||0),0);

  const downloadCert=async(cert)=>{
    const mod=MODULES.find(m=>m.id===cert.module_id);
    const {data:profile}=await sb.from("users").select("name,email").eq("id",user.id).single();
    await generateCertificate({studentName:profile?.name||profile?.email?.split("@")[0]||"Apprenant",moduleName:mod?.name||cert.module_id,completedAt:cert.issued_at,certificateCode:cert.certificate_code});
    toast.success("Certificat téléchargé!");
  };

  const claimCert=async(mod)=>{
    if(!user){toast.error("Connexion requise");return;}
    setGenerating(mod.id);
    try{
      const code=`SELMS-${Date.now().toString(36).toUpperCase()}-${Math.random().toString(36).slice(2,6).toUpperCase()}`;
      const {data}=await sb.from("certificates").insert({user_id:user.id,module_id:mod.id,certificate_code:code}).select().single();
      if(data){
        setCerts(c=>[data,...c]);
        const {data:profile}=await sb.from("users").select("name,email").eq("id",user.id).single();
        await generateCertificate({studentName:profile?.name||profile?.email?.split("@")[0]||"Apprenant",moduleName:mod.name,completedAt:new Date().toISOString(),certificateCode:code});
        toast.success("🏆 Certificat obtenu et téléchargé!");
      }
    }catch(e){toast.error(e.message);}finally{setGenerating(null);}
  };

  return (
    <div style={{minHeight:"100vh",background:"var(--bg-main)"}}>
      <Navbar/>
      <main style={{maxWidth:900,margin:"0 auto",padding:"2.5rem 1.5rem"}}>
        <div className="animate-slideUp" style={{marginBottom:"2.5rem"}}>
          <h1 style={{fontSize:"2rem",fontWeight:800,marginBottom:".4rem"}}>🏆 Mes Certificats</h1>
          <p style={{color:"var(--text-secondary)"}}>Complète un module pour obtenir ton certificat PDF officiel.</p>
        </div>

        <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:"1rem",marginBottom:"2.5rem"}}>
          {[{icon:"🏆",label:"Certificats obtenus",value:certs.length},{icon:"📚",label:"Modules validés",value:certs.length},{icon:"⏱️",label:"Heures certifiées",value:`${totalHours}h`}].map(s=>(
            <div key={s.label} className="card" style={{padding:"1.25rem",textAlign:"center"}}>
              <div style={{fontSize:"2rem",marginBottom:".35rem"}}>{s.icon}</div>
              <div style={{fontSize:"1.75rem",fontWeight:800,color:"var(--color-primary)"}}>{s.value}</div>
              <div style={{fontSize:".78rem",color:"var(--text-secondary)"}}>{s.label}</div>
            </div>
          ))}
        </div>

        <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(340px,1fr))",gap:"1.25rem"}}>
          {MODULES.map(mod=>{
            const cert=certs.find(c=>c.module_id===mod.id);
            return (
              <div key={mod.id} className="card" style={{padding:"1.5rem",border:cert?"1px solid rgba(22,163,74,.3)":"undefined",background:cert?"rgba(22,163,74,.03)":undefined}}>
                {cert&&<div style={{position:"absolute",top:12,right:12,background:"#16a34a",color:"#fff",borderRadius:999,padding:".2rem .65rem",fontSize:".7rem",fontWeight:700}}>✓ Obtenu</div>}
                <div style={{display:"flex",gap:"1rem",marginBottom:"1rem"}}>
                  <span style={{fontSize:"2.25rem"}}>{mod.icon}</span>
                  <div>
                    <div style={{fontWeight:700,fontSize:".93rem"}}>{mod.name}</div>
                    <div style={{fontSize:".75rem",color:"var(--text-muted)"}}>{mod.hours}h · PDF officiel</div>
                  </div>
                </div>
                {cert?(
                  <button onClick={()=>downloadCert(cert)} style={{width:"100%",padding:".65rem",borderRadius:9,border:"none",background:"linear-gradient(135deg,#16a34a,#15803d)",color:"#fff",fontWeight:700,cursor:"pointer",fontSize:".88rem"}}>
                    ⬇️ Télécharger le PDF
                  </button>
                ):(
                  <button onClick={()=>claimCert(mod)} disabled={generating===mod.id} style={{width:"100%",padding:".65rem",borderRadius:9,border:"none",background:`linear-gradient(135deg,var(--color-primary),var(--color-secondary))`,color:"#fff",fontWeight:700,cursor:"pointer",fontSize:".88rem",opacity:generating===mod.id?.7:1}}>
                    {generating===mod.id?"⏳ Génération…":"🏆 Obtenir le certificat"}
                  </button>
                )}
              </div>
            );
          })}
        </div>
      </main>
    </div>
  );
}