import { useState } from "react";
import { Navbar } from "@/components/Navbar";
import { useAuth } from "@/hooks/useAuth";
import toast from "react-hot-toast";

const PROJECTS = [
  {id:"proj-01",mod:"🔧",title:"Calculatrice RPN",diff:"medium",desc:"Stack + notation polonaise inversée.",hours:4,tags:["Python","Stack","CLI"]},
  {id:"proj-02",mod:"🏗️",title:"E-Commerce System Design",diff:"hard",desc:"5 Design Patterns, SOLID, UML complet.",hours:8,tags:["Design Patterns","SOLID","UML"]},
  {id:"proj-03",mod:"🌐",title:"Twitter Clone Full-Stack",diff:"hard",desc:"Auth, tweets, likes, followers, WebSocket.",hours:40,tags:["React","Node.js","PostgreSQL"],featured:true},
  {id:"proj-04",mod:"⚙️",title:"Containerize & Deploy",diff:"hard",desc:"Dockerfile multi-stage, K8s, GitHub Actions.",hours:12,tags:["Docker","Kubernetes","CI/CD"]},
  {id:"proj-05",mod:"💼",title:"Build Your Portfolio",diff:"medium",desc:"Site déployé, 5 articles, 3 contributions OS.",hours:20,tags:["Next.js","SEO","GitHub"]},
  {id:"proj-06",mod:"⚡",title:"CLI Tool en Rust",diff:"hard",desc:"Analyseur de code source, rapports JSON/HTML.",hours:15,tags:["Rust","CLI","Serde"]},
  {id:"proj-07",mod:"🤖",title:"Chatbot RAG",diff:"hard",desc:"Réponses sur la doc du LMS, pgvector + LLM.",hours:20,tags:["OpenAI","RAG","Supabase"]},
  {id:"proj-08",mod:"⛓️",title:"DApp Certification NFT",diff:"hard",desc:"Certificats comme NFTs sur Sepolia testnet.",hours:25,tags:["Solidity","ethers.js","React"]},
];

const DC={easy:"#16a34a",medium:"#d97706",hard:"#dc2626",expert:"#7c3aed"};
const DL={easy:"Facile",medium:"Moyen",hard:"Difficile",expert:"Expert"};

export default function Projects() {
  const { user } = useAuth();
  const [filter, setFilter] = useState("all");
  const [submitting, setSubmitting] = useState(null);

  const filtered = filter === "all" ? PROJECTS : PROJECTS.filter(p => p.diff === filter);

  const submit = async (p) => {
    if (!user) { toast.error("Connexion requise"); return; }
    const url = prompt(`URL GitHub pour "${p.title}":`);
    if (!url) return;
    setSubmitting(p.id);
    await new Promise(r => setTimeout(r, 800));
    toast.success("✅ Projet soumis! En attente de review.");
    setSubmitting(null);
  };

  return (
    <div style={{ minHeight: "100vh", background: "var(--bg-main)" }}>
      <Navbar />
      <main style={{ maxWidth: 1100, margin: "0 auto", padding: "2.5rem 1.5rem" }}>
        <div className="animate-slideUp" style={{ marginBottom: "2rem" }}>
          <h1 style={{ fontSize: "2.25rem", fontWeight: 800, marginBottom: ".5rem" }}>🚀 Projets Capstone</h1>
          <p style={{ color: "var(--text-secondary)" }}>Projets réels portfolio-ready. Soumets ton repo GitHub après complétion.</p>
        </div>

        <div style={{ display: "flex", gap: ".5rem", marginBottom: "2rem" }}>
          {[["all","Tous"],["medium","Moyen"],["hard","Difficile"]].map(([v,l])=>(
            <button key={v} onClick={() => setFilter(v)} style={{ padding: ".45rem .9rem", borderRadius: 8, border: "1px solid var(--border)", background: filter===v?"var(--color-primary)":"var(--bg-elevated)", color: filter===v?"#fff":"var(--text-secondary)", fontWeight: 600, fontSize: ".82rem", cursor: "pointer" }}>{l}</button>
          ))}
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(320px,1fr))", gap: "1.25rem" }}>
          {filtered.map(p => (
            <div key={p.id} className="card animate-slideUp" style={{ padding: "1.5rem", display: "flex", flexDirection: "column", position: "relative" }}>
              {p.featured && <div style={{ position: "absolute", top: -1, left: 20, background: "linear-gradient(135deg,#eab308,#d97706)", color: "#fff", padding: ".15rem .7rem", borderRadius: "0 0 8px 8px", fontSize: ".7rem", fontWeight: 800 }}>⭐ POPULAIRE</div>}
              <div style={{ display: "flex", alignItems: "center", gap: ".65rem", marginBottom: ".9rem", marginTop: p.featured?".6rem":0 }}>
                <span style={{ fontSize: "1.75rem" }}>{p.mod}</span>
                <span style={{ fontSize: ".72rem", fontWeight: 700, padding: ".2rem .65rem", borderRadius: 999, color: DC[p.diff], background: `${DC[p.diff]}15`, border: `1px solid ${DC[p.diff]}30` }}>{DL[p.diff]}</span>
              </div>
              <h2 style={{ fontSize: "1.05rem", fontWeight: 800, marginBottom: ".4rem" }}>{p.title}</h2>
              <p style={{ fontSize: ".83rem", color: "var(--text-secondary)", marginBottom: "1rem", flex: 1, lineHeight: 1.55 }}>{p.desc}</p>
              <div style={{ display: "flex", flexWrap: "wrap", gap: ".3rem", marginBottom: "1rem" }}>
                {p.tags.map(t => <span key={t} style={{ fontSize: ".7rem", padding: ".2rem .5rem", borderRadius: 6, background: "var(--bg-elevated)", color: "var(--text-secondary)", fontWeight: 600 }}>{t}</span>)}
              </div>
              <div style={{ display: "flex", alignItems: "center", gap: ".75rem" }}>
                <span style={{ fontSize: ".75rem", color: "var(--text-muted)" }}>⏱ ~{p.hours}h</span>
                <button onClick={() => submit(p)} disabled={submitting===p.id} style={{ marginLeft: "auto", padding: ".5rem 1rem", borderRadius: 8, border: "none", background: "var(--color-primary)", color: "#fff", fontWeight: 700, fontSize: ".82rem", cursor: "pointer", opacity: submitting===p.id?.7:1 }}>
                  {submitting===p.id?"⏳…":"📤 Soumettre"}
                </button>
              </div>
            </div>
          ))}
        </div>
      </main>
    </div>
  );
}