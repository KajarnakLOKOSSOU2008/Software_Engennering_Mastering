import Link from "next/link";
import { Navbar } from "@/components/Navbar";
import { useAuth } from "@/hooks/useAuth";
import { useProgress } from "@/hooks/useProgress";
import { useState } from "react";

const MODULES=[
  {id:"01-fondations",icon:"🔧",title:"Fondations",sub:"Algorithmes & Structures de Données",hours:80,difficulty:"Débutant",color:"#2563eb",topics:["Big O","Arrays","Linked Lists","Stacks","Trees","Graphs","Sorting"]},
  {id:"02-software-engineering",icon:"🏗️",title:"Software Engineering",sub:"Design Patterns & Architecture",hours:60,difficulty:"Intermédiaire",color:"#7c3aed",topics:["SOLID","23 GoF Patterns","Clean Architecture","DDD","TDD","UML"]},
  {id:"03-fullstack",icon:"🌐",title:"Full-Stack Development",sub:"React, Node.js & Databases",hours:120,difficulty:"Avancé",color:"#059669",topics:["React Hooks","State Mgmt","REST API","GraphQL","PostgreSQL","MongoDB","Redis"]},
  {id:"04-devops",icon:"⚙️",title:"DevOps & Cloud",sub:"Docker, Kubernetes & CI/CD",hours:60,difficulty:"Avancé",color:"#dc2626",topics:["Docker","Kubernetes","GitHub Actions","Terraform","AWS","Monitoring"]},
  {id:"05-career",icon:"💼",title:"Carrière",sub:"Interviews & Soft Skills",hours:40,difficulty:"Tous niveaux",color:"#d97706",topics:["Soft Skills","Coding Interviews","System Design","Portfolio","Négociation"]},
  {id:"06-extra-stacks",icon:"⚡",title:"Extra Stacks",sub:"Rust, Go, Python DS, React Native",hours:100,difficulty:"Avancé",color:"#0891b2",topics:["Rust","Go","Python","Pandas","React Native","Expo"]},
  {id:"07-security-performance",icon:"🔐",title:"Sécurité & Performance",sub:"OWASP, Web Vitals, Microservices",hours:80,difficulty:"Expert",color:"#6d28d9",topics:["OWASP Top 10","XSS/CSRF","JWT","Core Web Vitals","Redis Cache","Microservices"]},
  {id:"08-open-source-entrepreneurship",icon:"🌍",title:"Open Source & Entrepreneuriat",sub:"Freelance, Startup, Contribution",hours:50,difficulty:"Tous niveaux",color:"#0f766e",topics:["GitHub PRs","Freelance","Startup","MVP","SaaS","Product Market Fit"]},
  {id:"09-ai-ml-engineering",icon:"🤖",title:"IA & ML pour Ingénieurs",sub:"LLMs, RAG, Production AI",hours:80,difficulty:"Avancé",color:"#b45309",topics:["OpenAI API","Anthropic","RAG","pgvector","LangChain","Monitoring IA"]},
  {id:"10-blockchain-web3",icon:"⛓️",title:"Blockchain & Web3",sub:"Solidity, DeFi, NFTs",hours:60,difficulty:"Avancé",color:"#6366f1",topics:["Solidity","ERC-20","ERC-721","Hardhat","ethers.js","DeFi"]},
];

export default function CoursesIndex() {
  const {user}=useAuth();
  const {getModuleProgress}=useProgress(user?.id);
  const [search,setSearch]=useState("");
  const [filter,setFilter]=useState("all");

  const filtered=MODULES.filter(m=>{
    const q=search.toLowerCase();
    const matchSearch=!q||m.title.toLowerCase().includes(q)||m.sub.toLowerCase().includes(q)||m.topics.some(t=>t.toLowerCase().includes(q));
    const matchFilter=filter==="all"||(filter==="beginner"&&m.difficulty==="Débutant")||(filter==="intermediate"&&m.difficulty==="Intermédiaire")||(filter==="advanced"&&(m.difficulty==="Avancé"||m.difficulty==="Expert"))||(filter==="all-levels"&&m.difficulty==="Tous niveaux");
    return matchSearch&&matchFilter;
  });

  return (
    <div style={{minHeight:"100vh",background:"var(--bg-main)"}}>
      <Navbar/>
      <main style={{maxWidth:1100,margin:"0 auto",padding:"2.5rem 1.5rem"}}>
        <div className="animate-slideUp" style={{marginBottom:"2rem"}}>
          <h1 style={{fontSize:"2.25rem",fontWeight:800,marginBottom:".5rem"}}>📚 Modules de Formation</h1>
          <p style={{color:"var(--text-secondary)"}}>700+ heures · 10 modules · Du débutant à l'expert</p>
        </div>

        <div style={{display:"flex",gap:"1rem",marginBottom:"2rem",flexWrap:"wrap"}}>
          <input value={search} onChange={e=>setSearch(e.target.value)} placeholder="🔍  Rechercher (React, Docker, SQL…)" style={{flex:1,minWidth:240,padding:".7rem 1.1rem",borderRadius:10,border:"1px solid var(--border)",background:"var(--bg-surface)",color:"var(--text-primary)",fontSize:".9rem"}}/>
          <div style={{display:"flex",gap:".4rem"}}>
            {[["all","Tous"],["beginner","Débutant"],["intermediate","Intermédiaire"],["advanced","Avancé/Expert"],["all-levels","Tous niveaux"]].map(([v,l])=>(
              <button key={v} onClick={()=>setFilter(v)} style={{padding:".55rem .9rem",borderRadius:9,border:"1px solid var(--border)",background:filter===v?"var(--color-primary)":"var(--bg-surface)",color:filter===v?"#fff":"var(--text-secondary)",fontWeight:600,fontSize:".8rem",cursor:"pointer",whiteSpace:"nowrap"}}>{l}</button>
            ))}
          </div>
        </div>

        <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(300px,1fr))",gap:"1.25rem"}} className="stagger">
          {filtered.map(mod=>{
            const ids=mod.topics.map((_,i)=>`${mod.id.split("-")[0]}-0${i+1}`);
            const pct=getModuleProgress?getModuleProgress(ids):0;
            return (
              <Link key={mod.id} href={`/courses/${mod.id}`} style={{textDecoration:"none"}}>
                <div className="card animate-slideUp" style={{padding:"1.4rem",cursor:"pointer",height:"100%",display:"flex",flexDirection:"column"}}>
                  <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:"1rem"}}>
                    <span style={{fontSize:"2.4rem"}}>{mod.icon}</span>
                    <span style={{fontSize:".72rem",fontWeight:700,padding:".2rem .7rem",borderRadius:999,color:mod.color,background:`${mod.color}15`,border:`1px solid ${mod.color}25`}}>{mod.difficulty}</span>
                  </div>
                  <h2 style={{fontSize:"1.1rem",fontWeight:800,marginBottom:".3rem"}}>{mod.title}</h2>
                  <p style={{fontSize:".83rem",color:"var(--text-secondary)",marginBottom:"1rem",flex:1,lineHeight:1.55}}>{mod.sub}</p>
                  <div style={{display:"flex",flexWrap:"wrap",gap:".3rem",marginBottom:"1rem"}}>
                    {mod.topics.slice(0,4).map(t=><span key={t} style={{fontSize:".7rem",padding:".2rem .5rem",borderRadius:6,background:"var(--bg-elevated)",color:"var(--text-secondary)",fontWeight:600}}>{t}</span>)}
                    {mod.topics.length>4&&<span style={{fontSize:".7rem",padding:".2rem .5rem",borderRadius:6,background:"var(--bg-elevated)",color:"var(--text-muted)"}}>+{mod.topics.length-4}</span>}
                  </div>
                  <div style={{display:"flex",gap:"1rem",fontSize:".75rem",color:"var(--text-muted)",marginBottom:".75rem"}}>
                    <span>⏱ {mod.hours}h</span><span>📖 {mod.topics.length} sujets</span>
                  </div>
                  <div>
                    <div style={{display:"flex",justifyContent:"space-between",fontSize:".72rem",marginBottom:".3rem"}}>
                      <span style={{color:"var(--text-muted)"}}>Progression</span>
                      <span style={{fontWeight:700,color:pct>0?"var(--color-primary)":"var(--text-muted)"}}>{pct}%</span>
                    </div>
                    <div className="progress-bar"><div className="progress-fill" style={{width:`${pct}%`,background:mod.color}}/></div>
                  </div>
                </div>
              </Link>
            );
          })}
        </div>
      </main>
    </div>
  );
}