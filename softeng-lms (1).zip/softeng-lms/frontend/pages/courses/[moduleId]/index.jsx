import { useRouter } from 'next/router';
import Link from 'next/link';
import { Navbar } from '@/components/Navbar';
import { useAuth } from '@/hooks/useAuth';
import { useProgress } from '@/hooks/useProgress';

const STATIC_MODULES = {
  '06-extra-stacks': { id:'06-extra-stacks', title:'Extra Stacks', icon:'⚡', description:'Rust, Go, Python DS, React Native.', duration_hours:100, difficulty:'advanced', lessons:[{id:'06-01',title:'Rust : Sécurité Mémoire',duration_minutes:120},{id:'06-02',title:'Go : Microservices',duration_minutes:120},{id:'06-03',title:'Python Data Science',duration_minutes:120},{id:'06-04',title:'React Native Mobile',duration_minutes:120}] },
  '07-security-performance': { id:'07-security-performance', title:'Sécurité & Performance', icon:'🔐', description:'OWASP, Web Vitals, Microservices, Kafka.', duration_hours:80, difficulty:'expert', lessons:[{id:'07-01',title:'OWASP Top 10',duration_minutes:120},{id:'07-02',title:'Core Web Vitals',duration_minutes:120},{id:'07-03',title:'Architecture Microservices',duration_minutes:120}] },
  '08-open-source-entrepreneurship': { id:'08-open-source-entrepreneurship', title:'Open Source & Entrepreneuriat', icon:'🌍', description:'Contribuer à l'OS, Freelance, Startup.', duration_hours:50, difficulty:'all-levels', lessons:[{id:'08-01',title:'Contribuer à l'Open Source',duration_minutes:90},{id:'08-02',title:'Freelance Tech',duration_minutes:90},{id:'08-03',title:'Créer une Startup Tech',duration_minutes:120}] },
  '09-ai-ml-engineering': { id:'09-ai-ml-engineering', title:'IA & ML pour Ingénieurs', icon:'🤖', description:'LLMs, OpenAI, Anthropic, RAG, pgvector.', duration_hours:80, difficulty:'advanced', lessons:[{id:'09-01',title:'LLMs & APIs (OpenAI, Anthropic)',duration_minutes:90},{id:'09-02',title:'RAG & Bases Vectorielles',duration_minutes:120},{id:'09-03',title:'IA en Production',duration_minutes:90}] },
  '10-blockchain-web3': { id:'10-blockchain-web3', title:'Blockchain & Web3', icon:'⛓️', description:'Solidity, ERC-20, ERC-721, DeFi.', duration_hours:60, difficulty:'advanced', lessons:[{id:'10-01',title:'Blockchain Fundamentals',duration_minutes:90},{id:'10-02',title:'Solidity : Smart Contracts',duration_minutes:120}] },
};

function loadModule(moduleId) {
  try {
    switch(moduleId) {
      case '01-fondations': return require('@/content/modules/01-fondations/module.json');
      case '02-software-engineering': return require('@/content/modules/02-software-engineering/module.json');
      case '03-fullstack': return require('@/content/modules/03-fullstack/module.json');
      case '04-devops': return require('@/content/modules/04-devops/module.json');
      case '05-career': return require('@/content/modules/05-career/module.json');
      default: return STATIC_MODULES[moduleId] || null;
    }
  } catch { return STATIC_MODULES[moduleId] || null; }
}

export default function ModulePage() {
  const { query } = useRouter();
  const { moduleId } = query;
  const { user } = useAuth();
  const { isCompleted, getModuleProgress } = useProgress(user?.id);

  if (!moduleId) return null;
  const mod = loadModule(moduleId);

  if (!mod) return (
    <div style={{ minHeight:'100vh', background:'var(--bg-main)' }}>
      <Navbar />
      <div style={{ textAlign:'center', padding:'4rem', color:'var(--text-muted)' }}>
        <div style={{ fontSize:'3rem', marginBottom:'1rem' }}>🔍</div>
        <p>Module introuvable</p>
        <Link href="/courses" style={{ color:'var(--color-primary)' }}>← Retour aux modules</Link>
      </div>
    </div>
  );

  const lessonIds = (mod.lessons||[]).map(l => l.id);
  const pct = getModuleProgress ? getModuleProgress(lessonIds) : 0;

  return (
    <div style={{ minHeight:'100vh', background:'var(--bg-main)' }}>
      <Navbar />
      <main style={{ maxWidth:880, margin:'0 auto', padding:'2.5rem 1.5rem' }}>
        <div style={{ fontSize:'.82rem', color:'var(--text-muted)', marginBottom:'1.5rem' }}>
          <Link href="/courses" style={{ color:'var(--color-primary)', textDecoration:'none' }}>Modules</Link>
          {' › '}{mod.title}
        </div>

        <div className="card animate-slideUp" style={{ padding:'2rem', marginBottom:'2rem', background:'linear-gradient(135deg,rgba(37,99,235,.06),rgba(124,58,237,.04))' }}>
          <div style={{ display:'flex', gap:'1.5rem', alignItems:'flex-start' }}>
            <span style={{ fontSize:'3.5rem', flexShrink:0 }}>{mod.icon}</span>
            <div style={{ flex:1 }}>
              <h1 style={{ fontSize:'1.75rem', fontWeight:800, marginBottom:'.4rem' }}>{mod.title}</h1>
              <p style={{ color:'var(--text-secondary)', marginBottom:'1rem' }}>{mod.description}</p>
              <div style={{ display:'flex', gap:'1.5rem', fontSize:'.82rem', color:'var(--text-muted)', marginBottom:'1.25rem' }}>
                <span>⏱ {mod.duration_hours}h</span>
                <span>📖 {mod.lessons?.length||0} leçons</span>
                <span>🎯 {mod.difficulty}</span>
              </div>
              <div>
                <div style={{ display:'flex', justifyContent:'space-between', fontSize:'.8rem', marginBottom:'.4rem' }}>
                  <span style={{ color:'var(--text-muted)' }}>Progression</span>
                  <span style={{ fontWeight:700, color:'var(--color-primary)' }}>{pct}%</span>
                </div>
                <div className="progress-bar"><div className="progress-fill" style={{ width:`${pct}%` }}/></div>
              </div>
            </div>
          </div>
        </div>

        <h2 style={{ fontSize:'1.1rem', fontWeight:700, marginBottom:'1rem' }}>Leçons ({mod.lessons?.length||0})</h2>
        <div style={{ display:'flex', flexDirection:'column', gap:'.6rem' }}>
          {(mod.lessons||[]).map((lesson, i) => {
            const done = isCompleted ? isCompleted(lesson.id) : false;
            return (
              <Link key={lesson.id} href={`/courses/${moduleId}/${lesson.id}`} style={{ textDecoration:'none' }}>
                <div className="card" style={{ padding:'1rem 1.4rem', display:'flex', alignItems:'center', gap:'1rem', cursor:'pointer', background:done?'rgba(22,163,74,.04)':undefined, borderColor:done?'rgba(22,163,74,.25)':undefined }}>
                  <div style={{ width:34, height:34, borderRadius:'50%', flexShrink:0, background:done?'#16a34a':'var(--bg-elevated)', border:`2px solid ${done?'#16a34a':'var(--border)'}`, display:'flex', alignItems:'center', justifyContent:'center', fontWeight:800, fontSize:done?'1rem':'.85rem', color:done?'#fff':'var(--text-muted)' }}>
                    {done ? '✓' : i+1}
                  </div>
                  <div style={{ flex:1 }}>
                    <div style={{ fontWeight:700, fontSize:'.92rem' }}>{lesson.title}</div>
                    <div style={{ fontSize:'.75rem', color:'var(--text-muted)', marginTop:'.15rem' }}>⏱ {lesson.duration_minutes} min</div>
                  </div>
                  <span style={{ color:'var(--text-muted)' }}>›</span>
                </div>
              </Link>
            );
          })}
        </div>
      </main>
    </div>
  );
}