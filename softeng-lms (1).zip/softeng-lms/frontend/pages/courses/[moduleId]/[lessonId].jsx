import { useRouter } from "next/router";
import { useState, useEffect } from "react";
import Link from "next/link";
import dynamic from "next/dynamic";
import { Navbar } from "@/components/Navbar";
import { useAuth } from "@/hooks/useAuth";
import { useProgress } from "@/hooks/useProgress";
import { executeCode } from "@/lib/codeExecution";
import toast from "react-hot-toast";

const Editor = dynamic(() => import("@monaco-editor/react"), { ssr: false });
const Markdown = dynamic(() => import("react-markdown"), { ssr: false });

const DATA = {
  "01-fondations": require("@/content/modules/01-fondations/module.json"),
  "02-software-engineering": require("@/content/modules/02-software-engineering/module.json"),
  "03-fullstack": require("@/content/modules/03-fullstack/module.json"),
  "04-devops": require("@/content/modules/04-devops/module.json"),
  "05-career": require("@/content/modules/05-career/module.json"),
};

export default function LessonPage() {
  const { query } = useRouter();
  const { moduleId, lessonId } = query;
  const { user } = useAuth();
  const { markComplete, isCompleted } = useProgress(user?.id);
  const [code, setCode] = useState("# Écris ton code ici\nprint('Hello World!')");
  const [output, setOutput] = useState("");
  const [running, setRunning] = useState(false);
  const [completed, setCompleted] = useState(false);

  const mod = moduleId ? DATA[moduleId] : null;
  const lesson = mod?.lessons?.find(l => l.id === lessonId);

  useEffect(() => {
    if (lesson && isCompleted) setCompleted(isCompleted(lesson.id));
  }, [lesson, isCompleted]);

  const runCode = async () => {
    setRunning(true); setOutput("⏳ Exécution…");
    const r = await executeCode({ code, language: "python" });
    setOutput(r.output || r.error || "(Aucun output)");
    setRunning(false);
  };

  const complete = async () => {
    if (markComplete && lesson) {
      await markComplete(lesson.id);
      setCompleted(true);
      toast.success("✅ Leçon complétée!");
    }
  };

  if (!lesson) return (
    <div style={{ minHeight: "100vh", background: "var(--bg-main)" }}>
      <Navbar/>
      <div style={{ textAlign: "center", padding: "4rem", color: "var(--text-muted)" }}>Leçon introuvable</div>
    </div>
  );

  return (
    <div style={{ minHeight: "100vh", background: "var(--bg-main)" }}>
      <Navbar/>
      <main style={{ maxWidth: 1100, margin: "0 auto", padding: "2rem 1.5rem" }}>
        {/* Breadcrumb */}
        <div style={{ fontSize: ".82rem", color: "var(--text-muted)", marginBottom: "1.5rem" }}>
          <Link href="/courses" style={{ color: "var(--color-primary)", textDecoration: "none" }}>Modules</Link>
          {" › "}
          <Link href={`/courses/${moduleId}`} style={{ color: "var(--color-primary)", textDecoration: "none" }}>{mod?.title}</Link>
          {" › "}
          {lesson.title}
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "2rem" }}>
          {/* Content */}
          <div>
            <div className="card" style={{ padding: "2rem", marginBottom: "1.5rem" }}>
              <h1 style={{ fontSize: "1.5rem", fontWeight: 800, marginBottom: ".5rem" }}>{lesson.title}</h1>
              <div style={{ display: "flex", gap: "1rem", fontSize: ".78rem", color: "var(--text-muted)", marginBottom: "1.5rem" }}>
                <span>⏱ {lesson.duration_minutes} min</span>
                {completed && <span style={{ color: "#16a34a", fontWeight: 700 }}>✓ Complétée</span>}
              </div>
              <article className="prose">
                <p style={{ color: "var(--text-secondary)", lineHeight: 1.7 }}>
                  Contenu de la leçon <strong>{lesson.title}</strong>. Cette leçon couvre les concepts fondamentaux et pratiques avec des exemples de code.
                </p>
                <p style={{ color: "var(--text-secondary)", lineHeight: 1.7, marginTop: "1rem" }}>
                  Utilise l'éditeur de code à droite pour pratiquer. Exécute ton code et observe les résultats en temps réel.
                </p>
              </article>
            </div>
            {!completed && (
              <button onClick={complete} style={{ width: "100%", padding: ".75rem", borderRadius: 10, border: "none", background: "linear-gradient(135deg,#16a34a,#15803d)", color: "#fff", fontWeight: 700, cursor: "pointer", fontSize: ".95rem" }}>
                ✅ Marquer comme complétée
              </button>
            )}
          </div>

          {/* Code editor */}
          <div>
            <div className="card" style={{ overflow: "hidden" }}>
              <div style={{ background: "#1e293b", padding: ".6rem 1rem", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                <span style={{ color: "#7d8590", fontSize: ".78rem", fontFamily: "monospace" }}>main.py</span>
                <button onClick={runCode} disabled={running} style={{ padding: ".4rem 1rem", borderRadius: 7, border: "none", background: running?"#334155":"#16a34a", color: "#fff", fontWeight: 700, cursor: "pointer", fontSize: ".82rem" }}>
                  {running?"⟳ En cours…":"▶ Exécuter"}
                </button>
              </div>
              <Editor height="300px" language="python" value={code} onChange={v => setCode(v||"")} theme="vs-dark" options={{ fontSize: 14, fontFamily: "JetBrains Mono,monospace", minimap: { enabled: false }, padding: { top: 10 }, scrollBeyondLastLine: false }}/>
              <div style={{ background: "#0d1117", padding: "1rem", minHeight: 100 }}>
                <div style={{ fontSize: ".7rem", color: "#484f58", marginBottom: ".4rem", fontFamily: "monospace" }}>OUTPUT</div>
                <pre style={{ margin: 0, fontFamily: "JetBrains Mono,monospace", fontSize: 13, color: output.startsWith("❌")?"#f87171":"#e6edf3", whiteSpace: "pre-wrap" }}>
                  {output || <span style={{ color: "#484f58", fontStyle: "italic" }}>Appuie sur ▶ Exécuter…</span>}
                </pre>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}