import { useState, useEffect } from "react";
import Link from "next/link";
import { Navbar } from "@/components/Navbar";

const POPULAR = ["React hooks","Docker","SOLID","Big O","System Design","Rust","Python","Kubernetes","SQL","LLM"];

export default function Search() {
  const [q, setQ] = useState("");
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!q.trim()) { setResults([]); return; }
    const t = setTimeout(() => {
      setLoading(true);
      fetch(`/api/search?q=${encodeURIComponent(q)}`)
        .then(r => r.json()).then(d => setResults(d.results||[])).finally(() => setLoading(false));
    }, 300);
    return () => clearTimeout(t);
  }, [q]);

  return (
    <div style={{ minHeight: "100vh", background: "var(--bg-main)" }}>
      <Navbar />
      <main style={{ maxWidth: 720, margin: "0 auto", padding: "3rem 1.5rem" }}>
        <div className="animate-slideUp">
          <h1 style={{ fontSize: "2rem", fontWeight: 800, textAlign: "center", marginBottom: ".5rem" }}>🔍 Rechercher</h1>
          <p style={{ color: "var(--text-secondary)", textAlign: "center", marginBottom: "2rem" }}>Leçons, modules, concepts…</p>

          <div style={{ position: "relative", marginBottom: "2rem" }}>
            <input autoFocus value={q} onChange={e=>setQ(e.target.value)} placeholder="React hooks, Docker, SOLID, Big O…"
              style={{ width: "100%", padding: "1rem 1.25rem 1rem 3.5rem", borderRadius: 14, fontSize: "1.05rem", border: `2px solid ${q?"var(--color-primary)":"var(--border)"}`, background: "var(--bg-surface)", color: "var(--text-primary)", outline: "none" }}/>
            <span style={{ position: "absolute", left: "1.1rem", top: "50%", transform: "translateY(-50%)", fontSize: "1.2rem" }}>🔍</span>
            {q && <button onClick={() => { setQ(""); setResults([]); }} style={{ position: "absolute", right: "1rem", top: "50%", transform: "translateY(-50%)", background: "none", border: "none", cursor: "pointer", fontSize: "1.1rem", color: "var(--text-muted)" }}>✕</button>}
          </div>

          {!q && (
            <div>
              <div style={{ fontSize: ".75rem", color: "var(--text-muted)", fontWeight: 700, marginBottom: ".6rem", letterSpacing: ".07em" }}>POPULAIRES</div>
              <div style={{ display: "flex", flexWrap: "wrap", gap: ".4rem" }}>
                {POPULAR.map(t => <button key={t} onClick={() => setQ(t)} style={{ padding: ".35rem .9rem", borderRadius: 999, border: "1px solid var(--border)", background: "var(--bg-elevated)", color: "var(--text-secondary)", fontSize: ".82rem", fontWeight: 600, cursor: "pointer" }}>{t}</button>)}
              </div>
            </div>
          )}

          {loading && <div style={{ textAlign: "center", padding: "3rem", color: "var(--text-muted)" }}>Recherche…</div>}

          {!loading && q && results.length === 0 && (
            <div style={{ textAlign: "center", padding: "3rem", color: "var(--text-muted)" }}>
              <div style={{ fontSize: "3rem", marginBottom: "1rem" }}>🤔</div>
              <div style={{ fontWeight: 600 }}>Aucun résultat pour « {q} »</div>
            </div>
          )}

          {results.length > 0 && (
            <div className="card" style={{ overflow: "hidden" }}>
              {results.map((r, i) => (
                <Link key={r.id} href={r.href} style={{ textDecoration: "none" }}>
                  <div style={{ display: "flex", alignItems: "center", gap: "1rem", padding: ".85rem 1.25rem", borderBottom: i < results.length-1 ? "1px solid var(--border)" : "none", transition: "background .15s" }}
                    onMouseEnter={e => e.currentTarget.style.background = "var(--bg-elevated)"}
                    onMouseLeave={e => e.currentTarget.style.background = "transparent"}>
                    <span style={{ fontSize: "1.2rem" }}>📖</span>
                    <div style={{ flex: 1 }}>
                      <div style={{ fontWeight: 700, fontSize: ".9rem" }}>{r.title}</div>
                      <div style={{ fontSize: ".72rem", color: "var(--text-muted)", marginTop: ".15rem" }}>{r.module}</div>
                    </div>
                    <span style={{ color: "var(--text-muted)" }}>›</span>
                  </div>
                </Link>
              ))}
            </div>
          )}
        </div>
      </main>
    </div>
  );
}