import "../styles/globals.css";
import { useEffect } from "react";
import { AuthProvider } from "@/hooks/useAuth";
import { ThemeProvider } from "@/hooks/useTheme";
import { OfflineProvider } from "@/hooks/useOffline";
import { Toaster } from "react-hot-toast";
import Head from "next/head";
export default function App({ Component, pageProps }) {
  useEffect(() => {
    if ("serviceWorker" in navigator) navigator.serviceWorker.register("/sw.js").catch(()=>{});
  }, []);
  return (
    <ThemeProvider>
      <AuthProvider>
        <OfflineProvider>
          <Head>
            <title>SoftEng LMS — Formation Ingénieur Logiciel</title>
            <meta name="description" content="700+ heures de formation. Algorithmes, Full-Stack, DevOps, IA, Blockchain. Gratuit, offline, open-source." />
            <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover" />
            <meta name="theme-color" content="#2563eb" />
            <link rel="manifest" href="/manifest.json" />
          </Head>
          <Component {...pageProps} />
          <Toaster position="bottom-right" toastOptions={{ duration: 3000 }} />
        </OfflineProvider>
      </AuthProvider>
    </ThemeProvider>
  );
}