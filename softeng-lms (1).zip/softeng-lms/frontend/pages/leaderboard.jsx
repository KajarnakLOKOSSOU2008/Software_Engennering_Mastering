import { useState, useEffect } from "react";
import { Navbar } from "@/components/Navbar";
import { useAuth } from "@/hooks/useAuth";

const TABS=[{id:"xp",label:"⭐ XP"},{id:"exercises",label:"✅ Exercices"},{id:"streak",label:"🔥 Série"},{id:"lessons",label:"📚 Leçons"}];

export default function Leaderboard() {
  const {user}=useAuth();
  const [tab,setTab]=useState("xp");
  const [data,setData]=useState([]);
  const [loading,setLoading]=useState(true);

  useEffect(()=>{
    setLoading(true);
    fetch(`/api/leaderboard?metric=${tab}&limit=100`)
      .then(r=>r.json()).then(d=>{setData(d.leaderboard||[]);setLoading(false);}).catch(()=>setLoading(false));
  },[tab]);

  const getValue=r=>{if(tab==="xp")return `${r.xp} XP`;if(tab==="exercises")return r.exercises;if(tab==="streak")return `${r.streak}j`;return r.lessons;};
  const medal=r=>{if(r.rank===1)return "🥇";if(r.rank===2)return "🥈";if(r.rank===3)return "🥉";return r.rank;};
  const myRank=user?data.findIndex(r=>r.userId===user.id)+1:0;

  return (
    <div style={{minHeight:"100vh",background:"var(--bg-main)"}}>
      <Navbar/>
      <main style={{maxWidth:780,margin:"0 auto",padding:"2.5rem 1.5rem"}}>
        <div className="animate-slideUp" style={{textAlign:"center",marginBottom:"2.5rem"}}>
          <h1 style={{fontSize:"2.25rem",fontWeight:800,marginBottom:".5rem"}}>🏆 Classement</h1>
          <p style={{color:"var(--text-secondary)"}}>Les apprenants les plus actifs</p>
          {myRank>0&&<div style={{marginTop:"1rem",display:"inline-flex",alignItems:"center",gap:".5rem",background:"rgba(37,99,235,.1)",border:"1px solid rgba(37,99,235,.2)",borderRadius:999,padding:".4rem 1.1rem",fontSize:".85rem",fontWeight:700,color:"var(--color-primary)"}}>Ton rang : #{myRank}</div>}
        </div>

        <div style={{display:"flex",gap:".4rem",marginBottom:"1.75rem",background:"var(--bg-elevated)",padding:".35rem",borderRadius:12}}>
          {TABS.map(t=>(
            <button key={t.id} onClick={()=>setTab(t.id)} style={{flex:1,padding:".5rem",borderRadius:9,border:"none",background:tab===t.id?"var(--bg-surface)":"transparent",boxShadow:tab===t.id?"var(--shadow-sm)":"none",color:tab===t.id?"var(--color-primary)":"var(--text-secondary)",fontWeight:700,fontSize:".8rem",cursor:"pointer",transition:"all .2s"}}>{t.label}</button>
          ))}
        </div>

        {/* Podium top 3 */}
        {!loading&&data.length>=3&&(
          <div style={{display:"flex",justifyContent:"center",alignItems:"flex-end",gap:"1rem",marginBottom:"2rem"}}>
            {[data[1],data[0],data[2]].map((row,i)=>{
              const heights=[80,110,65];const colors=["#94a3b8","#eab308","#cd7f32"];
              return row&&(
                <div key={row.rank} style={{textAlign:"center",flex:i===1?1.2:1}}>
                  <div style={{width:44,height:44,borderRadius:"50%",background:`linear-gradient(135deg,${colors[i]},${colors[i]}88)`,display:"flex",alignItems:"center",justifyContent:"center",margin:"0 auto .35rem",color:"#fff",fontWeight:800,fontSize:"1.1rem",border:`3px solid ${colors[i]}`}}>{row.name[0]?.toUpperCase()}</div>
                  <div style={{fontWeight:700,fontSize:".82rem",marginBottom:".2rem"}}>{row.name}</div>
                  <div style={{fontWeight:800,color:colors[i],marginBottom:".4rem"}}>{getValue(row)}</div>
                  <div style={{height:heights[i],background:`${colors[i]}33`,borderRadius:"10px 10px 0 0",border:`1px solid ${colors[i]}55`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:"1.5rem"}}>{medal(row)}</div>
                </div>
              );
            })}
          </div>
        )}

        <div className="card" style={{overflow:"hidden"}}>
          {loading?Array.from({length:10}).map((_,i)=>(
            <div key={i} style={{display:"flex",alignItems:"center",gap:"1rem",padding:"1rem 1.25rem",borderBottom:"1px solid var(--border)"}}>
              <div className="skeleton" style={{width:32,height:32,borderRadius:"50%"}}/><div className="skeleton" style={{flex:1,height:18}}/><div className="skeleton" style={{width:60,height:18}}/>
            </div>
          )):data.map((row,idx)=>(
            <div key={row.userId} style={{display:"flex",alignItems:"center",gap:"1rem",padding:".8rem 1.25rem",borderBottom:idx<data.length-1?"1px solid var(--border)":"none",background:row.userId===user?.id?"rgba(37,99,235,.05)":"transparent",transition:"background .15s"}}
              onMouseEnter={e=>{if(row.userId!==user?.id)e.currentTarget.style.background="var(--bg-elevated)"}}
              onMouseLeave={e=>{if(row.userId!==user?.id)e.currentTarget.style.background="transparent"}}>
              <div style={{width:36,textAlign:"center",fontWeight:800,fontSize:row.rank<=3?"1.2rem":".85rem",flexShrink:0}}>{medal(row)}</div>
              <div style={{width:36,height:36,borderRadius:"50%",flexShrink:0,background:"linear-gradient(135deg,var(--color-primary),var(--color-secondary))",display:"flex",alignItems:"center",justifyContent:"center",color:"#fff",fontWeight:700}}>{row.name[0]?.toUpperCase()}</div>
              <div style={{flex:1}}>
                <div style={{fontWeight:700,fontSize:".88rem",color:row.userId===user?.id?"var(--color-primary)":"var(--text-primary)"}}>{row.name}{row.userId===user?.id&&<span style={{fontSize:".7rem",color:"var(--color-primary)"}}> (vous)</span>}</div>
                <div style={{fontSize:".72rem",color:"var(--text-muted)"}}>{row.exercises} ex · {row.lessons} leçons</div>
              </div>
              <div style={{fontWeight:800,color:row.rank===1?"#eab308":"var(--color-primary)"}}>{getValue(row)}</div>
              {row.streak>=7&&<span className="badge badge-amber">🔥 {row.streak}j</span>}
            </div>
          ))}
        </div>
      </main>
    </div>
  );
}