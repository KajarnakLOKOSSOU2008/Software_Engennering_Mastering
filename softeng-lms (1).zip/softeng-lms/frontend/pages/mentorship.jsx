import { useState } from "react";
import { Navbar } from "@/components/Navbar";
import { useAuth } from "@/hooks/useAuth";
import toast from "react-hot-toast";

const MENTORS = [
  {id:"m1",name:"Aminata Diallo",role:"Senior Engineer @ Google",skills:["Python","Algorithms","System Design"],rating:4.9,sessions:124,available:true,bg:"linear-gradient(135deg,#7c3aed,#2563eb)"},
  {id:"m2",name:"Kofi Asante",role:"Staff Engineer @ Meta",skills:["React","JavaScript","Architecture"],rating:4.8,sessions:89,available:true,bg:"linear-gradient(135deg,#059669,#0891b2)"},
  {id:"m3",name:"Fatima Ndiaye",role:"DevOps Lead @ Airbnb",skills:["Docker","Kubernetes","Go"],rating:4.7,sessions:67,available:false,bg:"linear-gradient(135deg,#dc2626,#ea580c)"},
  {id:"m4",name:"Moussa Traoré",role:"CTO @ Fintech Startup",skills:["Node.js","SQL","React"],rating:5.0,sessions:42,available:true,bg:"linear-gradient(135deg,#0284c7,#6366f1)"},
];

export default function Mentorship() {
  const { user } = useAuth();
  const [selected, setSelected] = useState(null);
  const [msg, setMsg] = useState("");
  const [sending, setSending] = useState(false);

  const send = async () => {
    if (!user) { toast.error("Connexion requise"); return; }
    if (!msg.trim()) { toast.error("Message requis"); return; }
    setSending(true);
    await new Promise(r => setTimeout(r, 1000));
    toast.success(`Demande envoyée à ${selected.name}!`);
    setSelected(null); setMsg(""); setSending(false);
  };

  return (
    <div style={{ minHeight: "100vh", background: "var(--bg-main)" }}>
      <Navbar />
      <main style={{ maxWidth: 1000, margin: "0 auto", padding: "2.5rem 1.5rem" }}>
        <div className="animate-slideUp" style={{ marginBottom: "2.5rem" }}>
          <h1 style={{ fontSize: "2.25rem", fontWeight: 800, marginBottom: ".5rem" }}>🤝 Mentorship</h1>
          <p style={{ color: "var(--text-secondary)" }}>Sessions 1-on-1 avec des ingénieurs expérimentés. Code review, career guidance.</p>
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(280px,1fr))", gap: "1.25rem" }}>
          {MENTORS.map(m => (
            <div key={m.id} className="card" style={{ padding: "1.5rem", position: "relative" }}>
              <div style={{ position: "absolute", top: 12, right: 12, padding: ".2rem .65rem", borderRadius: 999, fontSize: ".7rem", fontWeight: 700, background: m.available?"#d1fae5":"#fee2e2", color: m.available?"#065f46":"#991b1b" }}>
                {m.available?"● Disponible":"● Occupé"}
              </div>
              <div style={{ display: "flex", gap: ".9rem", alignItems: "center", marginBottom: "1rem" }}>
                <div style={{ width: 48, height: 48, borderRadius: "50%", background: m.bg, display: "flex", alignItems: "center", justifyContent: "center", color: "#fff", fontWeight: 800, fontSize: "1.15rem", flexShrink: 0 }}>{m.name[0]}</div>
                <div>
                  <div style={{ fontWeight: 800 }}>{m.name}</div>
                  <div style={{ fontSize: ".75rem", color: "var(--text-secondary)" }}>{m.role}</div>
                </div>
              </div>
              <div style={{ display: "flex", flexWrap: "wrap", gap: ".3rem", marginBottom: ".9rem" }}>
                {m.skills.map(s => <span key={s} style={{ fontSize: ".7rem", padding: ".2rem .55rem", borderRadius: 6, background: "var(--bg-elevated)", color: "var(--text-secondary)", fontWeight: 600 }}>{s}</span>)}
              </div>
              <div style={{ display: "flex", gap: "1rem", fontSize: ".75rem", color: "var(--text-muted)", marginBottom: "1rem" }}>
                <span>⭐ {m.rating}</span><span>📅 {m.sessions} sessions</span>
              </div>
              <button onClick={() => m.available && setSelected(m)} disabled={!m.available} style={{ width: "100%", padding: ".65rem", borderRadius: 9, border: "none", background: m.available?"linear-gradient(135deg,var(--color-primary),var(--color-secondary))":"var(--border)", color: m.available?"#fff":"var(--text-muted)", fontWeight: 700, cursor: m.available?"pointer":"default", fontSize: ".88rem" }}>
                {m.available?"📨 Demander une session":"Indisponible"}
              </button>
            </div>
          ))}
        </div>
      </main>

      {selected && (
        <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,.55)", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 999, padding: "1rem" }} onClick={e => { if(e.target===e.currentTarget) setSelected(null); }}>
          <div className="card animate-slideUp" style={{ padding: "2rem", maxWidth: 460, width: "100%" }}>
            <div style={{ display: "flex", gap: "1rem", alignItems: "center", marginBottom: "1.5rem" }}>
              <div style={{ width: 46, height: 46, borderRadius: "50%", background: selected.bg, display: "flex", alignItems: "center", justifyContent: "center", color: "#fff", fontWeight: 800, fontSize: "1.1rem" }}>{selected.name[0]}</div>
              <div><div style={{ fontWeight: 800 }}>{selected.name}</div><div style={{ fontSize: ".78rem", color: "var(--text-secondary)" }}>{selected.role}</div></div>
            </div>
            <textarea value={msg} onChange={e=>setMsg(e.target.value)} placeholder={`Message pour ${selected.name.split(" ")[0]}…`} rows={5} style={{ width: "100%", padding: ".75rem", borderRadius: 9, border: "1px solid var(--border)", background: "var(--bg-elevated)", color: "var(--text-primary)", fontSize: ".9rem", resize: "none", fontFamily: "var(--font-body)", marginBottom: "1rem" }}/>
            <div style={{ display: "flex", gap: ".75rem" }}>
              <button onClick={() => setSelected(null)} style={{ flex: 1, padding: ".65rem", borderRadius: 9, border: "1px solid var(--border)", background: "var(--bg-elevated)", color: "var(--text-secondary)", fontWeight: 700, cursor: "pointer" }}>Annuler</button>
              <button onClick={send} disabled={sending} style={{ flex: 2, padding: ".65rem", borderRadius: 9, border: "none", background: "linear-gradient(135deg,var(--color-primary),var(--color-secondary))", color: "#fff", fontWeight: 700, cursor: "pointer", opacity: sending?.7:1 }}>
                {sending?"⏳ Envoi…":"📨 Envoyer"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}