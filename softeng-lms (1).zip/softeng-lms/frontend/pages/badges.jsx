import { Navbar } from "@/components/Navbar";
import { useAuth } from "@/hooks/useAuth";
import { useState, useEffect } from "react";
import { createClient } from "@supabase/supabase-js";

const sb = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL, process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY);
const EMOJI = { 'first-step':'👣','ten-exercises':'✅','twenty-exercises':'🔥','fifty-exercises':'⚡','streak-7':'🗓️','streak-30':'🌟','module-1':'🔧','module-2':'🏗️','module-3':'🌐','graduate':'🎓' };

export default function Badges() {
  const { user } = useAuth();
  const [badges, setBadges] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) { setLoading(false); return; }
    Promise.all([
      sb.from("badges").select("*").order("created_at"),
      sb.from("user_badges").select("badge_id,earned_at").eq("user_id", user.id),
    ]).then(([{ data: all }, { data: earned }]) => {
      const em = Object.fromEntries((earned||[]).map(b=>[b.badge_id,b.earned_at]));
      setBadges((all||[]).map(b=>({...b, earned: b.id in em, earned_at: em[b.id]||null})));
      setLoading(false);
    });
  }, [user]);

  const earnedCount = badges.filter(b => b.earned).length;

  return (
    <div style={{ minHeight: "100vh", background: "var(--bg-main)" }}>
      <Navbar />
      <main style={{ maxWidth: 880, margin: "0 auto", padding: "2.5rem 1.5rem" }}>
        <div className="animate-slideUp" style={{ textAlign: "center", marginBottom: "2.5rem" }}>
          <h1 style={{ fontSize: "2.25rem", fontWeight: 800, marginBottom: ".5rem" }}>🏅 Badges</h1>
          <p style={{ color: "var(--text-secondary)" }}>Débloque des badges en progressant dans ta formation</p>
          {!loading && <div style={{ marginTop: "1rem", display: "inline-flex", alignItems: "center", gap: "1rem", background: "rgba(37,99,235,.08)", border: "1px solid rgba(37,99,235,.2)", borderRadius: 999, padding: ".5rem 1.25rem" }}>
            <span style={{ fontWeight: 700, color: "var(--color-primary)", fontSize: ".9rem" }}>{earnedCount} / {badges.length} badges</span>
            <div style={{ width: 120, height: 6, background: "var(--border)", borderRadius: 999, overflow: "hidden" }}>
              <div style={{ height: "100%", width: `${(earnedCount/badges.length)*100}%`, background: "linear-gradient(90deg,var(--color-primary),var(--color-secondary))", borderRadius: 999 }}/>
            </div>
          </div>}
        </div>

        {loading ? (
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(190px,1fr))", gap: "1rem" }}>
            {Array.from({length:10}).map((_,i)=><div key={i} className="card skeleton" style={{height:140}}/>)}
          </div>
        ) : (
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(190px,1fr))", gap: "1rem" }}>
            {badges.map(b => (
              <div key={b.id} className="card" style={{ padding: "1.25rem", opacity: b.earned ? 1 : 0.45, filter: b.earned ? "none" : "grayscale(.5)", border: b.earned ? "1px solid rgba(37,99,235,.3)" : undefined, background: b.earned ? "linear-gradient(135deg,rgba(37,99,235,.04),rgba(124,58,237,.04))" : undefined, position: "relative" }}>
                {b.earned && <div style={{ position: "absolute", top: 10, right: 10, width: 20, height: 20, borderRadius: "50%", background: "#16a34a", display: "flex", alignItems: "center", justifyContent: "center", color: "#fff", fontSize: ".65rem", fontWeight: 800 }}>✓</div>}
                <div style={{ fontSize: "2.25rem", marginBottom: ".6rem" }}>{EMOJI[b.slug]||"🏅"}</div>
                <div style={{ fontWeight: 800, fontSize: ".9rem", marginBottom: ".3rem" }}>{b.name}</div>
                <div style={{ fontSize: ".75rem", color: "var(--text-muted)", lineHeight: 1.5 }}>{b.description}</div>
                {b.earned && b.earned_at && <div style={{ fontSize: ".68rem", color: "var(--color-primary)", marginTop: ".5rem", fontWeight: 600 }}>{new Date(b.earned_at).toLocaleDateString("fr-FR")}</div>}
                {!b.earned && <div style={{ fontSize: ".7rem", color: "var(--text-muted)", marginTop: ".4rem" }}>🔒 Verrouillé</div>}
              </div>
            ))}
          </div>
        )}
      </main>
    </div>
  );
}