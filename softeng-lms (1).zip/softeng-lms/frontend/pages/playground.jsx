import { useState, useCallback } from "react";
import dynamic from "next/dynamic";
import { Navbar } from "@/components/Navbar";
import { executeCode } from "@/lib/codeExecution";
import toast from "react-hot-toast";

const Editor=dynamic(()=>import("@monaco-editor/react"),{ssr:false});

const LANGS=[{id:"python",label:"Python",icon:"🐍"},{id:"javascript",label:"JavaScript",icon:"🟨"},{id:"typescript",label:"TypeScript",icon:"🔷"},{id:"rust",label:"Rust",icon:"🦀"},{id:"go",label:"Go",icon:"🐹"},{id:"java",label:"Java",icon:"☕"},{id:"cpp",label:"C++",icon:"⚡"},{id:"c",label:"C",icon:"🔩"},{id:"bash",label:"Bash",icon:"🐚"},{id:"sql",label:"SQL",icon:"🗄️"},{id:"php",label:"PHP",icon:"🐘"},{id:"ruby",label:"Ruby",icon:"💎"}];

const STARTERS={
  python:"# Python Playground\nprint(\"Hello, World!\")\n\nfor i in range(5):\n    print(f\"Step {i}\")",
  javascript:"// JavaScript Playground\nconsole.log(\"Hello, World!\");\n\nconst greet = name => `Hello, ${name}!`;\nconsole.log(greet(\"Engineer\"));",
  rust:"fn main() {\n    println!(\"Hello, World!\");\n    let v: Vec<i32> = (1..=5).collect();\n    println!(\"\\{:?}\\", v);\n}",
  go:"package main\n\nimport \"fmt\"\n\nfunc main() {\n    fmt.Println(\"Hello, World!\")\n    for i := 1; i <= 5; i++ {\n        fmt.Printf(\"Step %d\\n\", i)\n    }\n}",
  java:"public class Main {\n    public static void main(String[] args) {\n        System.out.println(\"Hello, World!\");\n    }\n}",
  cpp:"#include <iostream>\nusing namespace std;\nint main() { cout << \"Hello, World!\" << endl; return 0; }",
  c:"#include <stdio.h>\nint main() { printf(\"Hello, World!\\n\"); return 0; }",
  bash:"#!/bin/bash\necho \"Hello, World!\"\nfor i in 1 2 3; do echo \"Step $i\"; done",
  sql:"CREATE TABLE users (id INT, name TEXT);\nINSERT INTO users VALUES (1,\"Alice\"),(2,\"Bob\");\nSELECT * FROM users;",
  typescript:"const greet = (name: string): string => `Hello, ${name}!`;\nconsole.log(greet(\"Engineer\"));",
  php:"<?php\necho \"Hello, World!\\n\";\n$names=[\"Alice\",\"Bob\"];\nforeach($names as $n){echo \"Hello $n!\\n\";}",
  ruby:"puts \"Hello, World!\"\n5.times{|i| puts \"Step #{i}\"}",
};

export default function Playground() {
  const [lang,setLang]=useState("python");
  const [code,setCode]=useState(STARTERS.python);
  const [output,setOutput]=useState("");
  const [stdin,setStdin]=useState("");
  const [running,setRunning]=useState(false);
  const [theme,setTheme]=useState("vs-dark");
  const [history,setHistory]=useState([]);

  const handleLang=l=>{setLang(l);setCode(STARTERS[l]||"");setOutput("");};

  const run=useCallback(async()=>{
    if(running)return;
    setRunning(true);setOutput("⏳ Exécution…");
    const t0=Date.now();
    try{
      const r=await executeCode({code,language:lang,stdin});
      const elapsed=((Date.now()-t0)/1000).toFixed(2);
      const out=r.error?`❌ Erreur:
${r.error}`:r.output||"(Aucun output)";
      setOutput(`${out}

⏱ ${elapsed}s`);
      setHistory(h=>[{lang,snippet:code.slice(0,60),at:new Date().toLocaleTimeString()},...h.slice(0,9)]);
      r.error?toast.error("Erreur d'exécution"):toast.success("Exécuté!");
    }catch(e){setOutput(`❌ ${e.message}`);toast.error("Erreur réseau");}
    finally{setRunning(false);}
  },[code,lang,stdin,running]);

  return (
    <div style={{minHeight:"100vh",background:"var(--bg-main)",display:"flex",flexDirection:"column"}}>
      <Navbar/>
      {/* Toolbar */}
      <div style={{background:"var(--bg-surface)",borderBottom:"1px solid var(--border)",padding:".55rem 1.25rem",display:"flex",alignItems:"center",gap:"1rem",flexWrap:"wrap"}}>
        <div style={{display:"flex",gap:".3rem",flexWrap:"wrap",flex:1}}>
          {LANGS.map(l=>(
            <button key={l.id} onClick={()=>handleLang(l.id)} style={{padding:".3rem .65rem",borderRadius:7,border:`1px solid ${lang===l.id?"var(--color-primary)":"var(--border)"}`,background:lang===l.id?"rgba(37,99,235,.12)":"var(--bg-elevated)",color:lang===l.id?"var(--color-primary)":"var(--text-secondary)",fontWeight:lang===l.id?700:500,fontSize:".75rem",cursor:"pointer"}}>
              {l.icon} {l.label}
            </button>
          ))}
        </div>
        <div style={{display:"flex",gap:".5rem",alignItems:"center",flexShrink:0}}>
          <select value={theme} onChange={e=>setTheme(e.target.value)} style={{padding:".35rem .6rem",borderRadius:7,border:"1px solid var(--border)",background:"var(--bg-elevated)",color:"var(--text-secondary)",fontSize:".78rem",cursor:"pointer"}}>
            <option value="vs-dark">Dark</option><option value="light">Light</option><option value="hc-black">HC Black</option>
          </select>
          <button onClick={()=>{setCode(STARTERS[lang]||"");setOutput("");}} style={{padding:".38rem .8rem",borderRadius:7,border:"1px solid var(--border)",background:"var(--bg-elevated)",color:"var(--text-secondary)",fontSize:".8rem",cursor:"pointer"}}>↺ Reset</button>
          <button onClick={run} disabled={running} style={{padding:".45rem 1.2rem",borderRadius:8,background:running?"var(--border)":"linear-gradient(135deg,#16a34a,#15803d)",color:"#fff",border:"none",fontWeight:700,fontSize:".88rem",cursor:running?"default":"pointer",display:"flex",alignItems:"center",gap:".4rem"}}>
            {running?<><span className="animate-spin" style={{display:"inline-block"}}>⟳</span> En cours…</>:"▶ Exécuter (⌘↵)"}
          </button>
        </div>
      </div>
      {/* Editor / Output */}
      <div style={{flex:1,display:"grid",gridTemplateColumns:"1fr 1fr",minHeight:500}}>
        <div style={{borderRight:"1px solid var(--border)"}}>
          <div style={{padding:".4rem .9rem",background:"var(--bg-elevated)",borderBottom:"1px solid var(--border)",fontSize:".75rem",color:"var(--text-muted)",display:"flex",justifyContent:"space-between"}}>
            <span>main{LANGS.find(l=>l.id===lang)?.id==="python"?".py":LANGS.find(l=>l.id===lang)?.id==="javascript"?".js":"."+lang}</span>
            <span>{code.split("\n").length} lignes</span>
          </div>
          <Editor height="calc(100vh - 180px)" language={lang} value={code} onChange={v=>setCode(v||"")} theme={theme} options={{fontSize:14,fontFamily:"JetBrains Mono,monospace",minimap:{enabled:false},lineNumbers:"on",scrollBeyondLastLine:false,wordWrap:"on",tabSize:2,automaticLayout:true,padding:{top:12}}}/>
        </div>
        <div style={{display:"flex",flexDirection:"column",background:"#0d1117"}}>
          <div style={{padding:".4rem .9rem",background:"#161b22",borderBottom:"1px solid #21262d",display:"flex",alignItems:"center",gap:"1rem"}}>
            <span style={{fontSize:".75rem",color:"#7d8590",fontFamily:"monospace"}}>OUTPUT</span>
            {output&&<button onClick={()=>{navigator.clipboard.writeText(output);toast.success("Copié!");}} style={{fontSize:".7rem",color:"#7d8590",background:"none",border:"none",cursor:"pointer"}}>⎘ Copier</button>}
            <button onClick={()=>setOutput("")} style={{marginLeft:"auto",fontSize:".7rem",color:"#7d8590",background:"none",border:"none",cursor:"pointer"}}>✕</button>
          </div>
          <pre style={{flex:1,margin:0,padding:"1rem 1.25rem",fontFamily:"JetBrains Mono,monospace",fontSize:13,lineHeight:1.65,color:output.startsWith("❌")?"#f87171":"#e6edf3",overflowY:"auto",whiteSpace:"pre-wrap",wordBreak:"break-word"}}>
            {output||<span style={{color:"#484f58",fontStyle:"italic"}}>Appuie sur ▶ Exécuter…</span>}
          </pre>
          {history.length>0&&(
            <div style={{borderTop:"1px solid #21262d",padding:".5rem .9rem"}}>
              <div style={{fontSize:".7rem",color:"#484f58",marginBottom:".3rem"}}>HISTORIQUE</div>
              {history.map((h,i)=>(
                <div key={i} style={{fontSize:".72rem",color:"#7d8590",padding:".2rem .3rem",display:"flex",gap:".5rem"}}>
                  <span style={{color:LANGS.find(l=>l.id===h.lang)?.icon??"#388bfd"}}>{LANGS.find(l=>l.id===h.lang)?.icon}</span>
                  <span style={{flex:1,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap",fontFamily:"monospace"}}>{h.snippet}</span>
                  <span style={{flexShrink:0}}>{h.at}</span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}