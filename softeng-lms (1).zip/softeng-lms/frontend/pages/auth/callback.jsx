import { useEffect, useState } from "react";
import { useRouter } from "next/router";
import { createClient } from "@supabase/supabase-js";
const sb = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL, process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY);
export default function Callback() {
  const router = useRouter();
  const [error, setError] = useState(null);
  useEffect(() => {
    sb.auth.getSession().then(async ({ data: { session } }) => {
      if (session?.user) {
        await sb.from("users").upsert({ id: session.user.id, email: session.user.email, name: session.user.user_metadata?.full_name || session.user.email.split("@")[0] }, { onConflict: "id" });
        router.push("/");
      } else {
        setError("Session introuvable");
        setTimeout(() => router.push("/auth/login"), 3000);
      }
    }).catch(e => { setError(e.message); setTimeout(() => router.push("/auth/login"), 3000); });
  }, []);
  return (
    <div style={{minHeight:"100vh",display:"flex",alignItems:"center",justifyContent:"center",background:"var(--bg-main)"}}>
      {error ? (
        <div style={{textAlign:"center"}}><div style={{fontSize:"3rem",marginBottom:"1rem"}}>❌</div><h1>Erreur</h1><p style={{color:"var(--text-muted)"}}>{error}</p></div>
      ) : (
        <div style={{textAlign:"center"}}><div style={{fontSize:"3rem",marginBottom:"1rem",animation:"spin 1s linear infinite",display:"inline-block"}}>⟳</div><p style={{color:"var(--text-muted)"}}>Connexion en cours…</p></div>
      )}
    </div>
  );
}