import { useState } from "react";
import Link from "next/link";
import { useAuth } from "@/hooks/useAuth";
export default function Signup() {
  const [email,setEmail]=useState("");const [loading,setLoading]=useState(false);const [error,setError]=useState("");const [done,setDone]=useState(false);
  const {signInWithMagicLink,signInWithOAuth}=useAuth();
  const handleSubmit=async(e)=>{e.preventDefault();setLoading(true);setError("");const r=await signInWithMagicLink(email);r.success?setDone(true):setError(r.error);setLoading(false)};
  return (
    <div style={{minHeight:"100vh",background:"var(--bg-main)",display:"flex",alignItems:"center",justifyContent:"center",padding:"2rem 1rem"}}>
      <div style={{width:"100%",maxWidth:420}}>
        <div style={{textAlign:"center",marginBottom:"2rem"}}>
          <div style={{fontSize:"3rem",marginBottom:".5rem"}}>🎓</div>
          <h1 style={{fontSize:"1.5rem",fontWeight:800}}>SoftEng LMS</h1>
          <p style={{color:"var(--text-secondary)",fontSize:".9rem"}}>Formation gratuite — 700+ heures</p>
        </div>
        <div className="card" style={{padding:"2rem"}}>
          {done?(
            <div style={{textAlign:"center"}}>
              <div style={{fontSize:"3rem",marginBottom:"1rem"}}>📬</div>
              <h2 style={{fontWeight:800,marginBottom:".5rem"}}>Vérifie ton email!</h2>
              <p style={{color:"var(--text-secondary)"}}>Lien envoyé à <strong>{email}</strong></p>
            </div>
          ):(
            <>
              <h2 style={{fontWeight:800,marginBottom:".5rem"}}>Créer un compte</h2>
              <p style={{color:"var(--text-secondary)",fontSize:".88rem",marginBottom:"1.5rem"}}>Rejoins des milliers d'apprenants. 100% gratuit.</p>
              <div style={{display:"flex",flexDirection:"column",gap:".65rem",marginBottom:"1.5rem"}}>
                <button onClick={()=>signInWithOAuth("github")} style={{padding:".75rem",borderRadius:10,border:"1px solid var(--border)",background:"var(--bg-elevated)",fontWeight:700,cursor:"pointer",color:"var(--text-primary)"}}>🐙 Continuer avec GitHub</button>
                <button onClick={()=>signInWithOAuth("google")} style={{padding:".75rem",borderRadius:10,border:"1px solid var(--border)",background:"var(--bg-elevated)",fontWeight:700,cursor:"pointer",color:"var(--text-primary)"}}>🔍 Continuer avec Google</button>
              </div>
              <div style={{display:"flex",alignItems:"center",gap:"1rem",marginBottom:"1.5rem"}}>
                <div style={{flex:1,height:1,background:"var(--border)"}}/>
                <span style={{fontSize:".78rem",color:"var(--text-muted)"}}>ou email</span>
                <div style={{flex:1,height:1,background:"var(--border)"}}/>
              </div>
              <form onSubmit={handleSubmit}>
                <input type="email" value={email} onChange={e=>setEmail(e.target.value)} placeholder="tu@example.com" required style={{width:"100%",padding:".75rem 1rem",borderRadius:10,border:"1px solid var(--border)",background:"var(--bg-elevated)",color:"var(--text-primary)",fontSize:".92rem",marginBottom:"1rem"}}/>
                {error&&<div style={{color:"#dc2626",fontSize:".82rem",marginBottom:"1rem"}}>{error}</div>}
                <button type="submit" disabled={loading} style={{width:"100%",padding:".8rem",borderRadius:10,border:"none",background:loading?"var(--border)":"linear-gradient(135deg,var(--color-primary),var(--color-secondary))",color:"#fff",fontWeight:800,cursor:"pointer"}}>
                  {loading?"⏳ Envoi…":"✉️ Inscription gratuite"}
                </button>
              </form>
              <p style={{textAlign:"center",marginTop:"1.25rem",fontSize:".85rem",color:"var(--text-secondary)"}}>
                Déjà inscrit?{" "}<Link href="/auth/login" style={{color:"var(--color-primary)",fontWeight:700,textDecoration:"none"}}>Connexion</Link>
              </p>
            </>
          )}
        </div>
      </div>
    </div>
  );
}