const CACHE = 'softeng-lms-v1';
const STATIC = ['/', '/offline.html', '/manifest.json'];

self.addEventListener('install', e => {
  e.waitUntil(caches.open(CACHE).then(c => c.addAll(STATIC)).then(() => self.skipWaiting()));
});

self.addEventListener('activate', e => {
  e.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k)))).then(() => self.clients.claim()));
});

self.addEventListener('fetch', e => {
  const { request } = e;
  const url = new URL(request.url);
  if (url.pathname.startsWith('/api/')) {
    e.respondWith(
      fetch(request).then(r => { const clone = r.clone(); caches.open(CACHE).then(c => c.put(request, clone)); return r; })
        .catch(() => caches.match(request).then(r => r || new Response('{"error":"offline"}', { headers: { 'Content-Type': 'application/json' } })))
    );
    return;
  }
  e.respondWith(
    caches.match(request).then(cached => {
      const net = fetch(request).then(r => { caches.open(CACHE).then(c => c.put(request, r.clone())); return r; }).catch(() => null);
      return cached || net || caches.match('/offline.html');
    })
  );
});