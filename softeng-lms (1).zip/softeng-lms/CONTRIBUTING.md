# 🤝 Guide de Contribution

Merci de contribuer à SoftEng LMS!

## Comment contribuer

### 1. Ajouter du contenu pédagogique

```bash
# Créer une branche
git checkout -b content/mon-sujet

# Ajouter dans content/modules/XX-nom/module.json
# Respecter le format JSON des modules existants

# Commit + PR
git commit -m "content: Add lesson on X"
```

### 2. Améliorer le code

```bash
git checkout -b fix/bug-description
# ou
git checkout -b feature/nouvelle-feature

# Développer
cd frontend && npm run dev

# Tester
npm run lint
npm test

# PR avec description claire
```

## Format des modules

```json
{
  "id": "XX-nom",
  "title": "Titre",
  "slug": "nom",
  "icon": "🔧",
  "duration_hours": 60,
  "difficulty": "beginner|intermediate|advanced|expert|all-levels",
  "order": 1,
  "description": "Description courte.",
  "lessons": [
    {
      "id": "XX-01",
      "slug": "lesson-slug",
      "title": "Titre de la leçon",
      "duration_minutes": 60,
      "order": 1
    }
  ]
}
```

## Standards

- ✅ Code en français ou anglais (cohérent dans le fichier)
- ✅ Pas de secrets dans le code
- ✅ Tests pour les utilitaires
- ✅ Screenshots si changement UI

## Licence

MIT — Toutes contributions sont les bienvenues!