#!/usr/bin/env node
const { execSync } = require('child_process');
const fs = require('fs');
const path = require('path');
const readline = require('readline');

const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
const ask = q => new Promise(r => rl.question(q, r));
const c = { g: '\x1b[32m', b: '\x1b[34m', y: '\x1b[33m', r: '\x1b[31m', x: '\x1b[0m', bold: '\x1b[1m' };
const log = (m, col='x') => console.log(`${c[col]}${m}${c.x}`);

async function main() {
  console.clear();
  log('\n🎓 SoftEng LMS — Setup Automatique\n', 'bold');

  // Check Node
  const v = parseInt(execSync('node --version').toString().replace('v',''));
  if (v < 18) { log('❌ Node.js 18+ requis', 'r'); process.exit(1); }
  log('✅ Node.js OK', 'g');

  // Supabase keys
  log('\nTu as besoin d\'un projet Supabase (https://supabase.com)\n', 'b');
  const url = await ask('🔗 SUPABASE_URL: ');
  const anon = await ask('🔑 SUPABASE_ANON_KEY: ');
  const svc = await ask('🔑 SUPABASE_SERVICE_KEY (optionnel, Entrée pour passer): ');

  // Write .env.local
  const envPath = path.join(__dirname, '..', 'frontend', '.env.local');
  fs.writeFileSync(envPath, [
    `NEXT_PUBLIC_SUPABASE_URL=${url.trim()}`,
    `NEXT_PUBLIC_SUPABASE_ANON_KEY=${anon.trim()}`,
    `SUPABASE_SERVICE_KEY=${svc.trim()}`,
    `NEXT_PUBLIC_PISTON_API=https://emkc.org/api/v2/piston`,
    `NODE_ENV=development`,
  ].join('\n'));
  log('✅ .env.local créé', 'g');

  // Install deps
  log('\nInstallation des dépendances…', 'b');
  execSync('cd frontend && npm install', { stdio: 'inherit' });
  log('✅ Dépendances installées', 'g');

  log('\n' + '═'.repeat(55), 'g');
  log('✅ Setup terminé!', 'g');
  log('\n  cd frontend && npm run dev', 'bold');
  log('  Ouvre http://localhost:3000 🚀\n', 'b');
  log('  N\'oublie pas d\'exécuter backend/migrations/001_schema.sql\n  dans Supabase SQL Editor!\n', 'y');
  rl.close();
}

main().catch(e => { console.error(e); process.exit(1); });