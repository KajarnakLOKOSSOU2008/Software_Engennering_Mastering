# 🚀 Guide de Déploiement

## Option 1 : Vercel (Recommandé — Gratuit)

```bash
# Install CLI
npm i -g vercel

# Deploy
cd frontend
vercel --prod

# Variables à configurer sur vercel.com :
# NEXT_PUBLIC_SUPABASE_URL
# NEXT_PUBLIC_SUPABASE_ANON_KEY
# SUPABASE_SERVICE_KEY
```

## Option 2 : Docker

```bash
# Build
docker build -t softeng-lms ./frontend

# Run
docker run -p 3000:3000 \
  -e NEXT_PUBLIC_SUPABASE_URL=... \
  -e NEXT_PUBLIC_SUPABASE_ANON_KEY=... \
  softeng-lms
```

## Option 3 : Docker Compose (Stack complète)

```bash
# Copier .env
cp .env.example .env
# Remplir les variables

# Lancer
docker-compose up -d

# Arrêter
docker-compose down
```

## Supabase Setup

1. Créer un projet sur https://supabase.com
2. Aller dans **SQL Editor**
3. Exécuter `backend/migrations/001_schema.sql`
4. Copier les clés dans `.env.local`
5. Configurer Auth → URL Configuration:
   - Redirect URLs: `https://your-app.com/auth/callback`

## Variables d'environnement

| Variable | Description | Requis |
|----------|-------------|--------|
| `NEXT_PUBLIC_SUPABASE_URL` | URL du projet Supabase | ✅ |
| `NEXT_PUBLIC_SUPABASE_ANON_KEY` | Clé publique Supabase | ✅ |
| `SUPABASE_SERVICE_KEY` | Clé service (backend) | ✅ |
| `NEXT_PUBLIC_PISTON_API` | URL Piston API | Optionnel |
| `OPENAI_API_KEY` | Pour IA features | Optionnel |
| `ANTHROPIC_API_KEY` | Pour IA features | Optionnel |
| `RESEND_API_KEY` | Pour emails | Optionnel |

## Checklist avant mise en prod

- [ ] Variables d'environnement configurées
- [ ] Migrations SQL exécutées
- [ ] HTTPS actif
- [ ] Redirect URLs Supabase configurées
- [ ] Test auth (Magic Link + OAuth)
- [ ] Test code execution (Playground)
- [ ] Test PWA (install + offline)